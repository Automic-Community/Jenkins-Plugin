function delete_dyna_prop(ele) {

	var td = ele.parentElement;
	var tr = td.parentElement;
	// get dynamic property tr
	if (tr) {
		var dyna_prop_tr = getProp(tr, propfilter);
		if (dyna_prop_tr) {
			// getting all div containing del button
			var del_input_div = dyna_propDivFilter(dyna_prop_tr);
			if (del_input_div) {
				// getting all delete button
				var del_input = dyna_propDelFilter(del_input_div);
				if (del_input) {
					// delete all dynamic property
					for (var i = 0; i < del_input.length; i++) {
						del_input[i].click();
					}

				}
			}
		}
	}

}


function getProfile(ele){	
	var td = ele.parentElement;
	var tr = td.parentElement;	
	var profile_tr = getProp(tr, profilefilter);	
	if(profile_tr){
		return findSelectElement(profile_tr);
	}	
	return undefined;	
}

//disable profile on provision application
function trackChanges() {
	var workflowsEle= document.getElementsByClassName("workflow");	
	for (var i = 0; i < workflowsEle.length; i++) {
		var val = workflowsEle[i].value;
		// disabling profile field
		if(val){
		if(val.indexOf("(*)") > 0){
			var profileEle = getProfile(workflowsEle[i]);
			if(profileEle){
				profileEle.setAttribute("disabled", true);			
			}
			// enabling profile field
		}else{
			var profileEle = getProfile(workflowsEle[i]);
			if(profileEle){
				profileEle.removeAttribute('disabled');
			}
		}
	}
		
}
}

setInterval(trackChanges, 1000);


//filter Dyanamic property tr
function profilefilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Profile")
			return true;
	}
	return false;
}

//filter Dyanamic property tr
function propfilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Dynamic Properties")
			return true;
	}
	return false;
}

//find dyna_prop DIV inside tr
function dyna_propDivFilter(elem) {

	var list = elem.getElementsByClassName("dyna_prop");
	return list;
}

// find all delete button inside dyna_prop
function dyna_propDelFilter(elem) {
	var delEle = [];

	for (var i = 0; i < elem.length; i++) {
		var e = elem[i].getElementsByTagName("button");
		delEle.push(e[0]);
	}
	return delEle;
}

//enable and disable the "execute at" option
function enableDisableStartAt(ele){	
	var td = ele.parentElement;
	var tr = td.parentElement;
	var execAtEle = undefined;
	var queueEle = undefined;
	var val  = ele.value;
	if(tr){
		var exec_at_tr = getProp(tr, execAtfilter);
		var queue_tr = getProp(tr, queueFilter);
		if(exec_at_tr){
			execAtEle = exec_at_tr.getElementsByTagName("input")[0];			
		}
		if(queue_tr){
			queueEle = queue_tr.getElementsByTagName("select")[0];			
		}
	}	
	if(execAtEle && queueEle){
			if(val == "at"){				
					execAtEle.removeAttribute('disabled');
					queueEle.setAttribute("disabled", true);
					queueEle.value = ""
				
			}else if(val == "queue") {
				queueEle.removeAttribute('disabled');
				execAtEle.setAttribute("disabled", true);
				execAtEle.value="";
			}else{
				queueEle.setAttribute("disabled", true);
				execAtEle.setAttribute("disabled", true);
				execAtEle.value="";
				queueEle.value = ""
			}
	 }	
}

//enable and disable the "execute at" option
function enableDisableUserGroupSelect(ele){	
	var td = ele.parentElement;
	var tr = td.parentElement;
	var elements = [];
	
	var val  = ele.value;
	if(tr){
		while(tr = tr.nextSibling){
			var tds = tr.children;
			if(tds && tds.length >= 2){
				var td = tds[2];
				if(td){
					var e = td.getElementsByTagName("select")[0];					
						if(e){
							elements.push(e);
							if(elements.length == 2){
								break;
							}
						}
					}
				}
			}			
		}		
			
		
	if(elements){
		for (var i = 0; i < elements.length; i++) {
			if(val == "yes"){				
				elements[i].removeAttribute('disabled');
			
			}else{				
				elements[i].setAttribute("disabled", true);
			}
		}
	 }	
}



//enable and disable the "execute at" option
function enableDisableUserGroup(ele){	
	var td = ele.parentElement;
	var tr = td.parentElement;
	var elements = [];
	
	var val  = ele.value;
	if(tr){
		while(tr = tr.nextSibling){
			var tds = tr.children;
			if(tds && tds.length >= 2){
				var td = tds[2];
				if(td){
					var e = td.getElementsByTagName("select")[0];					
						if(e){
							elements.push(e);
							if(elements.length == 2){
								break;
							}
						}
					}
				}
			}			
		}		
			
		
	if(elements){
		for (var i = 0; i < elements.length; i++) {
			if(val != "no"){				
				elements[i].removeAttribute('disabled');
			
			}else{				
				elements[i].setAttribute("disabled", true);
			}
		}
	 }	
}


// filter Dyanamic property tr
function execAtfilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Execute At")
			return true;
	}
	return false;
}


//filter Dyanamic property tr
function startAtFilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Start At")
			return true;
	}
	return false;
}


//filter Dyanamic property tr
function queueFilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Queue")
			return true;
	}
	return false;
}


//this will start from the current element and get all of the next siblings
function getProp(elem, filter) {

	while (elem) {
		// if (elem.nodeType === 3) continue; // text node
		if (!filter || filter(elem))return elem;
		elem = elem.nextSibling;
	}
	return "";
}

function updatePropValue(ele){
	var table = findParent(ele, "TABLE");
	var tbody = findParent(table, "TBODY");
	var server = findTextFieldval(getProp(tbody.children[0], serverFilter));
	var user = findTextFieldval(getProp(tbody.children[0], userFilter));
	var pass = findTextFieldval(getProp(tbody.children[0], passFilter));
	var workflow = findSelectval(getProp(tbody.children[0], workflowFilter));
	// find value element

	var td = ele.parentElement;
	var tr = td.parentElement;
	var dyna_prop_tr = getProp(tr, propertyValueFilter);
	var propValEle = findInputElement(dyna_prop_tr);
	
	GeneralDynamicProperty.getDynaPropValue(server,user,pass,workflow,ele.value, function(t) {
		propValEle.value = t.responseObject();
	    })
}

function updatePropValueAppWrkflow(ele){
	var table = findParent(ele, "TABLE");
	var tbody = findParent(table, "TBODY");
	var server = findTextFieldval(getProp(tbody.children[0], serverFilter));
	var user = findTextFieldval(getProp(tbody.children[0], userFilter));
	var pass = findTextFieldval(getProp(tbody.children[0], passFilter));
	var workflow = findSelectval(getProp(tbody.children[0], workflowFilter));
	var application = findSelectval(getProp(tbody.children[0], applicationFilter));
	
	
	var pleaseSelectVal = "-Please Select-"
	if(application != pleaseSelectVal && workflow != pleaseSelectVal){
		var package1 = findTextFieldval(getProp(tbody.children[0], packageFilter));
		var profile = findSelectval(getProp(tbody.children[0], profileFilter));
		
		var td = ele.parentElement;
		var tr = td.parentElement;
		var dyna_prop_tr = getProp(tr, propertyValueFilter);
		var propValEle = findInputElement(dyna_prop_tr);
		
		DynamicProperty.getDynaPropValue(server,user,pass,workflow,application,package1,profile,ele.value, function(t) {
			propValEle.value = t.responseObject();
		    })
	}
	
}

//filter parent element
function findParent(ele, tagName) {

	while (ele = ele.parentNode) {
		var tag = ele.tagName;
		if (tag == tagName)
			return ele;
	}
	return "";
}

//filter server
function serverFilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Server")
			return true;
	}
	return false;
}

//filter server
function userFilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Full Username")
			return true;
	}
	return false;
}

function passFilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Password")
			return true;
	}
	return false;
}

function workflowFilter(elem) {

	var tds = elem.children;
	if(tds){
		for (var i = 0; i < tds.length; i++) {
			var content = tds[i].textContent;
			if (content == "Workflow")
				return true;
		}
	}
	
	return false;
}

function applicationFilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Application")
			return true;
	}
	return false;
}

function packageFilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Package")
			return true;
	}
	return false;
}

function profileFilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Profile")
			return true;
	}
	return false;
}

function propertyValueFilter(elem) {

	var tds = elem.children;
	for (var i = 0; i < tds.length; i++) {
		var content = tds[i].textContent;
		if (content == "Property Value")
			return true;
	}
	return false;
}

//find input element
function findInputElement(elem) {	
		var e = elem.getElementsByTagName("input");
		return e[0];	  
}

//find select element
function findSelectElement(elem) {	
		var e = elem.getElementsByTagName("select");
		return e[0];		    
}

// find input val
function findTextFieldval(elem) {	
		var e = elem.getElementsByTagName("input");
		var server = e[0];	
	    return server.value;
}
//find all textfield
function findSelectval(elem) {	
		var e = elem.getElementsByTagName("select");
		var server = e[0];	
	    return server.value;
}

function clearWkfPkgProfQueueOnAppChange(element) {	
	var wkfEle = undefined
	var pkgEle = undefined
	var profileEle = undefined
	var queueEle = undefined
	var execEle = undefined
	var startatEle = undefined

	var count = 0;
	
	
	var td = element.parentElement;
	var elem = td.parentElement;
	
	while(elem){

	var tds = elem.children;
	for (var i = 0; i < tds.length && tds[i] != td; i++) {
		
		  if(count == 7) break; 
	      var content = tds[i].textContent;
		  
		switch (content) {
		case "Package":
				var packageSelectElm = elem.getElementsByTagName("input")[0];
				packageSelectElm.value = ""
				count++;
				break;
		case "Workflow":
				var workflowSelectElm = findSelectElement(elem);
				workflowSelectElm.value = ""
				count++;
				break;		  
		case "Profile":
				var profileSelectElm = findSelectElement(elem);
				profileSelectElm.value = ""
				count++;
				break;    
	    case "Queue":
				var queueSelectElm = findSelectElement(elem);
				queueSelectElm.value = ""
				count++;
				break;     
		case "Start At":
				var startAtSelectElm = findSelectElement(elem);
				startAtSelectElm.selectedIndex = 0;
				count++;
				break;     
		case "Execute At": 
				execEle = elem.getElementsByTagName("input")[0];
				if(execEle){
					execEle.setAttribute("disabled", true);
					count++;
				}		
				break;
		}	  

	}
	if(count == 7){ break}; 
	elem = elem.nextSibling;

	}	
	
	clearInlineMessages();
	
	
}

function clearProfileQueue(element){
	
	var profileEle = undefined
	var queueEle = undefined
	var execEle = undefined
	var startatEle = undefined
	
	
var count = 0;//to break the loop
	
	
	var td = element.parentElement;
	var elem = td.parentElement;
	
	while(elem){

	var tds = elem.children;
	for (var i = 0; i < tds.length && tds[i] != td; i++) {	
		
	    var content = tds[i].textContent;
		  
		switch (content) {
			  
		case "Profile":
				var profileSelectElm = findSelectElement(elem);
				profileSelectElm.value = ""				
				break;    
	    case "Queue":
				var queueSelectElm = findSelectElement(elem);
				queueSelectElm.value = ""
				queueSelectElm.setAttribute("disabled", true);
				break;     
		case "Start At":
				var startAtSelectElm = findSelectElement(elem);
				startAtSelectElm.selectedIndex = 0;				
				break;     
		case "Execute At": 
				execEle = elem.getElementsByTagName("input")[0];
				if(execEle){
					execEle.setAttribute("disabled", true);					
				}		
				break;
		}	  

	}

	elem = elem.nextSibling;

	}	
	clearInlineMessages();
	
	
}

function clearInlineMessages(){
	
	var inlineMsg = document.getElementsByClassName("ok")
	for (var i = 0; i < inlineMsg.length; i++) {
		inlineMsg[i].style.display = "none"
   }
}
