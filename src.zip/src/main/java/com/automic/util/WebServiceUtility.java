package com.automic.util;

import java.io.StringReader;
import java.io.StringWriter;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.automic.rm.Entity;
import com.automic.rm.MainType;
import com.automic.rm.Property;
import com.automic.rm.Sync;
import com.automic.ws.ImportExportServiceSoap;
import com.automic.ws.ImportExportServiceSoapProxy;
import com.automic.ws.Result;

/**
 * Created with IntelliJ IDEA. User: Administrator Date: 7/22/13 Time: 12:15 PM To change this template use File |
 * Settings | File Templates.
 */
public class WebServiceUtility {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebServiceUtility.class);

    private ImportExportServiceSoap service;
    private String serverURL;
    private String user;
    private String pass;
    private String errorDetail;

    public WebServiceUtility(String server, String user, String pass) {
        service = new ImportExportServiceSoapProxy(server + "/service/importexportservice.asmx?wsdl");
        this.serverURL = server;
        this.user = user;
        this.pass = pass;
    }

    public String getErrorDetail() {
        return errorDetail;
    }

    private Result handleImportExportResult(Result result) throws InterruptedException, RemoteException {
        if (result != null) {
            // waiting until result is available
            while (result.getStatus() == 0) {
                TimeUnit.MILLISECONDS.sleep(100);
                result = service.getStatus(result.getToken());
            }
        }
        return result;
    }

    public boolean createDeploymentPackage(String packageName, String packageType, String appName, String folder,
            String owner) throws Exception {

        JAXBContext context = JAXBContext.newInstance(Sync.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        marshaller.setProperty(Marshaller.JAXB_NO_NAMESPACE_SCHEMA_LOCATION, "sync.xsd");

        Entity entity = new Entity();
        entity.setMainType(MainType.PACKAGE);
        Sync sync = new Sync();
        sync.getEntity().add(entity);

        Property p;
        p = new Property();
        p.setName("system_name");
        p.setValue(packageName);
        entity.getProperty().add(p);

        entity.setCustomType(packageType);

        p = new Property();
        p.setName("system_application.system_name");
        p.setValue(appName);
        entity.getProperty().add(p);

        p = new Property();
        p.setName("system_folder.system_name");
        p.setValue(folder);
        entity.getProperty().add(p);

        // Format owner -> Client/User/Department
        String ownerValue = "";
        String[] tempUserArr = owner.split("/");
        if (tempUserArr.length == 3) {
            ownerValue = owner;
        } else {
            int i = owner.indexOf("/");
            ownerValue = owner.substring(i + 1);
        }

        p = new Property();
        p.setName("system_owner.system_name");
        p.setValue(ownerValue);
        entity.getProperty().add(p);

        p = new Property();
        p.setName("system_description");
        p.setValue("created via Jenkins plugin");
        entity.getProperty().add(p);

        StringWriter sw = new StringWriter();
        marshaller.marshal(new JAXBElement<Sync>(new QName("", "Sync"), Sync.class, sync), sw);

        Result result = service._import(user, pass, "Package", "XML", true, sw.toString());

        result = handleImportExportResult(result);
        com.automic.ws.Error[] errors = result.getErrors();
        if ((errors != null) && (errors.length > 0)) {
            errorDetail = errors[0].getErrorDetail();
            return false;
        }
        return true;

    }

    public boolean testConnection() {
        boolean ret = false;
        errorDetail = "";
        try {
            LOGGER.info(String.format("Testing the connection for user[%s] and server[%s]", user, serverURL));
            Result result = service.export(user, pass, "UserGroup", "", 0, 1, "XML", new String[] { "system_name" },
                    "", "", new String[] {});

            result = handleImportExportResult(result);
            com.automic.ws.Error[] errors = result.getErrors();
            if ((errors != null) && (errors.length > 0)) {
                LOGGER.error("Unable to connect, errorcode[" + errors[0].getErrorCode() + "]. Possible reasons : "
                        + errors[0].getErrorDetail());
                errorDetail = "[" + errors[0].getErrorCode() + "]" + errors[0].getErrorDetail();
            } else {
                ret = true;
            }

        } catch (Exception ex) {
            LOGGER.error("Error while retrieving from ARA", ex);
            errorDetail = "[" + ex.getClass() + "]" + ex.getMessage();
        }

        return ret;
    }

    public boolean assignPackageComponents(String packageId, String appName, List<String> componentName)
            throws Exception {
        Result result = service.export(user, pass, "PackageComponentRelation", "", 0, 1000, "XML", new String[] {}, "",
                "", new String[] { "system_package.system_id eq '" + packageId + "'" });

        result = handleImportExportResult(result);

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        DocumentBuilder builder = dbf.newDocumentBuilder();

        Document doc = builder.parse(new InputSource(new StringReader(result.getData())));

        JAXBContext context = JAXBContext.newInstance(Sync.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();

        JAXBElement<Sync> jaxbSync = unmarshaller.unmarshal(doc.getDocumentElement(), Sync.class);
        Sync sync = jaxbSync.getValue();

        for (String component : componentName) {

            String componentId = getComponentId(appName, component);
            Entity e = new Entity();
            e.setMainType(MainType.PACKAGE_COMPONENT_RELATION);

            Property p;

            p = new Property();
            p.setIsIdentity(true);
            p.setName("system_package.system_id");
            p.setValue(packageId);
            e.getProperty().add(p);

            p = new Property();
            p.setIsIdentity(true);
            p.setName("system_component.system_id");
            p.setValue(componentId);
            e.getProperty().add(p);

            sync.getEntity().remove(e);

        }

        if (sync.getEntity().size() > 0) {

            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.setProperty(Marshaller.JAXB_NO_NAMESPACE_SCHEMA_LOCATION, "sync.xsd");

            StringWriter sw = new StringWriter();

            marshaller.marshal(new JAXBElement<Sync>(new QName("", "Sync"), Sync.class, sync), sw);

            result = service.delete(user, pass, "", "XML", true, sw.toString());
            result = handleImportExportResult(result);
            com.automic.ws.Error[] errors = result.getErrors();
            if ((errors != null) && (errors.length > 0)) {
                errorDetail = errors[0].getErrorDetail();
                return false;
            }
            return true;

        }

        return true;
    }

    public String getComponentId(String appName, String componentName) throws Exception {
        Result result = service.export(user, pass, "Component", "", 0, 1, "XML", new String[] { "system_id" }, "", "",
                new String[] { "system_application.system_name eq '" + appName + "'",
                        "system_name eq '" + componentName + "'" });

        result = handleImportExportResult(result);

        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();

        Document doc = builder.parse(new InputSource(new StringReader(result.getData())));

        XPath xPath = XPathFactory.newInstance().newXPath();
        NodeList nodes = (NodeList) xPath.evaluate("/Sync/Entity/Property/Value", doc.getDocumentElement(),
                XPathConstants.NODESET);
        for (int i = 0; i < nodes.getLength();) {
            Element e = (Element) nodes.item(i);
            return (e.getTextContent());
        }
        return null;
    }

    public String getPackageIdFromPackageName(String system_name, String customType) throws Exception {
        Result result = service.export(user, pass, "Package", customType, 0, 1000, "XML", new String[] { "system_id" },
                "", "", new String[] { "system_name eq '" + system_name + "'" });

        result = handleImportExportResult(result);

        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();

        Document doc = builder.parse(new InputSource(new StringReader(result.getData())));

        XPath xPath = XPathFactory.newInstance().newXPath();
        NodeList nodes = (NodeList) xPath.evaluate(
                "/Sync/Entity/Property[not(../../Entity/Property/Value > Value)]/Value", doc.getDocumentElement(),
                XPathConstants.NODESET);
        for (int i = 0; i < nodes.getLength();) {
            Element e = (Element) nodes.item(i);
            return (e.getTextContent());
        }
        return null;
    }

    public boolean setPackageProperty(String packageName, String packageType, String name, String value, String appName)
            throws Exception {
        JAXBContext context = JAXBContext.newInstance(Sync.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        marshaller.setProperty(Marshaller.JAXB_NO_NAMESPACE_SCHEMA_LOCATION, "sync.xsd");

        Entity entity = new Entity();
        entity.setMainType(MainType.PACKAGE);
        entity.setCustomType(packageType);
        Sync sync = new Sync();
        sync.getEntity().add(entity);

        String system_id = getPackageIdFromPackageName(packageName, packageType);

        Property p;
        p = new Property();
        p.setIsIdentity(true);
        p.setName("system_id");
        p.setValue(system_id);
        entity.getProperty().add(p);

        p = new Property();
        p.setName(name);
        p.setValue(value);
        entity.getProperty().add(p);

        StringWriter sw = new StringWriter();
        marshaller.marshal(new JAXBElement<Sync>(new QName("", "Sync"), Sync.class, sync), sw);

        Result result = service._import(user, pass, "Package", "XML", true, sw.toString());
        result = handleImportExportResult(result);
        com.automic.ws.Error[] errors = result.getErrors();
        if ((errors != null) && (errors.length > 0)) {
            errorDetail = errors[0].getErrorDetail();
            return false;
        }
        return true;

    }

    public boolean setPackageDynamicProperty(String packageName, String fullName, String value) throws Exception {

        JAXBContext context = JAXBContext.newInstance(Sync.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        marshaller.setProperty(Marshaller.JAXB_NO_NAMESPACE_SCHEMA_LOCATION, "sync.xsd");

        Entity entity = new Entity();
        entity.setMainType(MainType.DYNAMIC_PROPERTY);
        Sync sync = new Sync();
        sync.getEntity().add(entity);

        Property p;

        p = new Property();
        p.setIsIdentity(true);
        p.setName("system_on_entity.system_name");
        p.setValue(packageName);
        entity.getProperty().add(p);

        p = new Property();
        p.setName("system_type");
        p.setValue("SingleLineText");
        entity.getProperty().add(p);

        p = new Property();
        p.setName("system_mode");
        p.setValue("Static");
        entity.getProperty().add(p);

        p = new Property();
        p.setIsIdentity(true);
        p.setName("system_on_maintype");
        p.setValue(MainType.PACKAGE.value());
        entity.getProperty().add(p);

        p = new Property();
        p.setName("system_full_name");
        p.setIsIdentity(true);
        p.setValue(fullName);
        entity.getProperty().add(p);

        p = new Property();
        p.setName("system_value");
        p.setValue(value);
        entity.getProperty().add(p);

        StringWriter sw = new StringWriter();
        marshaller.marshal(new JAXBElement<Sync>(new QName("", "Sync"), Sync.class, sync), sw);

        Result result = service._import(user, pass, "DynamicProperty", "XML", true, sw.toString());
        result = handleImportExportResult(result);
        com.automic.ws.Error[] errors = result.getErrors();
        if ((errors != null) && (errors.length > 0)) {
            errorDetail = errors[0].getErrorDetail();
            return false;
        }

        return true;

    }

    public List<String> getSystemName(String sysMainType, String[] condition) {
        ArrayList<String> list = new ArrayList<String>();

        try {
            Result result = service.export(user, pass, sysMainType, "", 0, 1000, "XML", new String[] { "system_name" },
                    "", "", condition);
            result = handleImportExportResult(result);
            if (result.getErrors() != null && (result.getErrors().length > 0)) {
                String errorDetails = result.getErrors()[0].getErrorDetail();
                throw new Exception(errorDetails);
            }
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();

            Document doc = builder.parse(new InputSource(new StringReader(result.getData())));

            XPath xPath = XPathFactory.newInstance().newXPath();
            NodeList nodes = (NodeList) xPath.evaluate("/Sync/Entity/Property/Value", doc.getDocumentElement(),
                    XPathConstants.NODESET);
            for (int i = 0; i < nodes.getLength(); ++i) {
                Element e = (Element) nodes.item(i);
                list.add(e.getTextContent());
            }
        } catch (Exception ex) {
            LOGGER.error("Unable to retrieve data for " + sysMainType, ex);
        }
        return list;
    }

    public boolean checkPackageExist(String packageName, String packageType) throws Exception {

        boolean pckgExist = false;
        Result result = service.export(user, pass, "Package", packageType, 0, 1, "XML", new String[] { "system_id" },
                "", "", new String[] { "system_name eq '" + packageName + "'" });

        result = handleImportExportResult(result);
        com.automic.ws.Error[] errors = result.getErrors();
        if ((errors != null) && (errors.length > 0)) {
            errorDetail = errors[0].getErrorDetail();
            return false;
        }

        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();

        Document doc = builder.parse(new InputSource(new StringReader(result.getData())));

        XPath xPath = XPathFactory.newInstance().newXPath();
        NodeList nodes = (NodeList) xPath.evaluate("/Sync/Entity/Property/Value", doc.getDocumentElement(),
                XPathConstants.NODESET);

        if (nodes.getLength() > 0) {
            pckgExist = true;
        }
        return pckgExist;
    }

}
