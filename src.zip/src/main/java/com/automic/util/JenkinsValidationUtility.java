package com.automic.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Pattern;

import com.automic.constants.JenkinsConstants;
import com.automic.ws.rest.exceptions.RmWebServiceRuntimeException;

/**
 * Defines validation and utility methods.
 */
public final class JenkinsValidationUtility {
    public JenkinsValidationUtility() {
    }

    public static String validateConnectionParameter(String url, String userName) {
        String errMsg = validateServerURL(url);
        errMsg = (errMsg != null) ? errMsg : validateUserName(userName);
        return errMsg;
    }

    public static String validateServerURL(String value) {
        String errMsg = null;
        if (!CommonUtil.isNotEmpty(value)) {
            errMsg = "The Server is mandatory";
        } else if (!CommonUtil.isValidURL(value)) {
            errMsg = "Invalid server url";
        }
        return errMsg;
    }

    public static String validateUserName(String value) {
        String errMsg = null;
        if (!CommonUtil.isNotEmpty(value)) {
            errMsg = "User Name is mandatory";
        } else {
            errMsg = (value.indexOf("/") == -1) ? "Invalid User Name" : errMsg;
        }
        return errMsg;
    }

    public static String validatePackageName(String packageName) {
        String errMsg = null;
        if (!CommonUtil.isNotEmpty(packageName)) {
            errMsg = "Package name is mandatory";
        } else {
            Pattern pattern = Pattern.compile(JenkinsConstants.PCK_NAME);
            errMsg = pattern.matcher(packageName).matches() ? errMsg
                    : "Package Name can only contain alphanumeric characters, blanks, '.', '-', '_', '@', '$', '#' ";
        }
        return errMsg;
    }

    public static String validateExecutionTime(String date) {
        String errMsg = null;
        String msg = "Please enter the date time in the format " + JenkinsConstants.FORM_DATE_FORMAT;
        if (CommonUtil.isNotEmpty(date)) {
            SimpleDateFormat dateFormat = new SimpleDateFormat(JenkinsConstants.FORM_DATE_FORMAT);
            dateFormat.setTimeZone(TimeZone.getTimeZone(JenkinsConstants.ARA_TIMEZONE));
            dateFormat.setLenient(false);
            try {
                Date dateObject = dateFormat.parse(date);
                if (!dateFormat.format(dateObject).equals(date)) {
                    errMsg = msg;
                } else {
                    long currTime = System.currentTimeMillis();
                    if (currTime >= dateObject.getTime()) {
                        String utcTime = dateFormat.format(new Date(currTime));
                        return "Entered date time should be fututre time. Current UTC Time : " + utcTime;
                    }
                }
            } catch (ParseException pe) {
                errMsg = msg;
            }
        } else {
            errMsg = msg;
        }
        return errMsg;
    }

    public static String checkCompatibleARA(Exception ex) {
        String errMsg = null;
        if (ex instanceof RmWebServiceRuntimeException
                && ((RmWebServiceRuntimeException) ex).getExceptionCode() == JenkinsConstants.HTTP_NOTFOUND) {
            errMsg = "You might not be using compatible ARA version.";
        }
        return errMsg;
    }

}
