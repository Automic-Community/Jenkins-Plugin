/**
 * 
 */
package com.automic.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This Class represents resource ARAproperties.properties
 *
 */
public final class AraProperties {

    private static final Logger LOGGER = LoggerFactory.getLogger(AraProperties.class);
    private final Properties configProp = new Properties();

    private AraProperties() {
        InputStream iStream = this.getClass().getClassLoader().getResourceAsStream("ARAproperties.properties");

        if (iStream != null) {
            try {
                configProp.load(iStream);
                LOGGER.info("ARADeployment.properties file loaded successfully");
            } catch (IOException e) {
                LOGGER.error("Fail to load ARADeployment.properties from classpath ", e);
            }
        }
    }

    private static class LazyHolder {
        private static final AraProperties INSTANCE = new AraProperties();
    }

    public static AraProperties getInstance() {
        return LazyHolder.INSTANCE;
    }

    public String getProperty(String key) {
        return configProp.getProperty(key);
    }

    public boolean containsKey(String key) {
        return configProp.containsKey(key);
    }
}
