package com.automic.util;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import com.automic.constants.JenkinsConstants;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public final class CommonUtil {

    public static List<String> getUniqueValues(List<String> list) {
        Set<String> set = new HashSet<String>();
        set.addAll(list);
        List<String> uniqueValues = new ArrayList<String>();
        uniqueValues.addAll(set);
        return uniqueValues;
    }

    public static boolean isNotEmpty(String field) {
        return field != null && !field.isEmpty();
    }
    
    public static boolean isValidURL(String url) {
        URL u = null;
        try {
            u = new URL(url);
            u.toURI();
        } catch (MalformedURLException | URISyntaxException e) {
            return false;
        }
        return true;
    }

    public static String convertToARADateFormat(String executionTime) throws ParseException {
        SimpleDateFormat formDf = new SimpleDateFormat(JenkinsConstants.FORM_DATE_FORMAT);
        formDf.setTimeZone(TimeZone.getTimeZone(JenkinsConstants.ARA_TIMEZONE));
        
        SimpleDateFormat sdf = new SimpleDateFormat(JenkinsConstants.DATE_FORMAT);
        sdf.setTimeZone(TimeZone.getTimeZone(JenkinsConstants.ARA_TIMEZONE));
        return sdf.format(formDf.parse(executionTime));
    }
    
    public static List<String> getEntityList(JsonArray jDataArray) {
        List<String> entityList = new ArrayList<String>();
        for (JsonElement jsonElement : jDataArray) {
            JsonObject jObj = jsonElement.getAsJsonObject();
            entityList.add(jObj.get("name").getAsString());
        }
        return entityList;
    }
    
}
