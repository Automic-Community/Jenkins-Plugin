/**
 * 
 */
package com.automic.ws.rest.model.dynamicprop;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.automic.constants.DynPropertyConstants;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/**
 * @author shrutinambiar
 * 
 */
public class DynamicPropertyParser {

    public static List<DynamicProperty> getPropertyList(Map.Entry<String, JsonElement> properties) {
        List<DynamicProperty> dpropertyList = new ArrayList<DynamicProperty>();
        JsonObject jsonObj = properties.getValue().getAsJsonObject();
        for (Map.Entry<String, JsonElement> jObj : jsonObj.entrySet()) {
            DynamicProperty dproperty = new DynamicProperty();
            JsonObject jObject = jObj.getValue().getAsJsonObject();
            dproperty.setName(jObj.getKey());
            dproperty.setType(jObject.get("type").getAsString());
            dproperty.setCaption(jObject.get("caption").isJsonNull() ? null : jObject.get("caption").getAsString());
            fillChoiceAndValue(jObject, dproperty);
            dpropertyList.add(dproperty);
        }
        return dpropertyList;
    }

    private static void fillChoiceAndValue(JsonObject jObject, DynamicProperty dp) {
        StringBuilder value = new StringBuilder();
        switch (dp.getType()) {

            case DynPropertyConstants.MUTLICHOICE_TYPE:
                if (!jObject.get("choices").isJsonNull()) {
                    List<String> choices = new ArrayList<>();
                    JsonArray jArr = jObject.get("choices").getAsJsonArray();
                    for (JsonElement ele : jArr) {
                        choices.add(ele.getAsString());
                    }
                    dp.setChoices(choices);
                }

                if (!jObject.get("value").isJsonNull()) {
                    for (JsonElement ele : jObject.get("value").getAsJsonArray()) {
                        value.append(ele.getAsString());
                        value.append(",");
                    }

                    if (value.length() > 1) {
                        dp.setValue(value.deleteCharAt(value.length() - 1).toString());
                        dp.setDefaultValue(dp.getValue());
                    }
                }
                break;

            case DynPropertyConstants.LIST_TYPE:
                if (!jObject.get("value").isJsonNull()) {
                    for (JsonElement ele : jObject.get("value").getAsJsonArray()) {
                        value.append(ele.getAsString());
                        value.append(",");
                    }

                    if (value.length() > 1) {
                        dp.setValue(value.deleteCharAt(value.length() - 1).toString());
                        dp.setDefaultValue(dp.getValue());
                    }
                }
                break;

            case DynPropertyConstants.SINGLECHOICE_TYPE:
                if (!jObject.get("choices").isJsonNull()) {
                    List<String> choices = new ArrayList<>();
                    JsonArray jArr = jObject.get("choices").getAsJsonArray();
                    for (JsonElement ele : jArr) {
                        choices.add(ele.getAsString());
                    }
                    dp.setChoices(choices);
                }

                if (!jObject.get("value").isJsonNull()) {
                    dp.setValue(jObject.get("value").getAsString());
                    dp.setDefaultValue(dp.getValue());
                }

                break;

            case DynPropertyConstants.REFERENCE_TYPE:
                dp.setReferenceMainType(jObject.get("reference_main_type").getAsString());
                JsonObject jObj = jObject.getAsJsonObject("value");
                if (jObj != null) {
                    dp.setValue(jObj.get("name").getAsString());
                    dp.setDefaultValue(dp.getValue());
                }
                break;

            default:
                if (!jObject.get("value").isJsonNull()) {
                    dp.setValue(jObject.get("value").getAsString());
                    dp.setDefaultValue(dp.getValue());
                }
        }
    }

    public static JsonObject createJson(List<DynamicProperty> dynamicPorperties) {
        JsonObject propObj = null;
        for (DynamicProperty prop : dynamicPorperties) {
            JsonElement jVal = prop.toJson();
            if (jVal != null) {
                if (propObj == null) {
                    propObj = new JsonObject();
                }
                propObj.add(prop.getName(), jVal);
            }
        }
        return propObj;

    }

}
