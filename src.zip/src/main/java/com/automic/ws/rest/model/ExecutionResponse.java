package com.automic.ws.rest.model;

/**
 * 
 * entity represents the result of execution of a Workflow
 *
 */
public class ExecutionResponse {
    
    /**
     * Execution id
     */
    private String executionId;
    
    /**
     * status of workflow execution
     */
    private String status;
    
 
    /**
     * @param executionId
     * @param status
     */
    public ExecutionResponse(String executionId, String status) {
        super();
        this.executionId = executionId;
        this.status = status;
    }
    /**
     * @return the executionId
     */
    public String getExecutionId() {
        return executionId;
    }
    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }
    
    
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Workflow Execution Response [executionId=" + executionId + ", status=" + status + "]";
    }
    
}
