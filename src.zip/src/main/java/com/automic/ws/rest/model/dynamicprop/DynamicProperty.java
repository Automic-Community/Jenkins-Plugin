package com.automic.ws.rest.model.dynamicprop;

import java.util.List;

import com.automic.constants.DynPropertyConstants;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

/**
 * This class holds the data for single Dynamic Property in generic way. It also provides the method to convert object
 * into JSON format.
 */
public class DynamicProperty {

    private String name;
    private String value;
    private String defaultValue;
    private String type;
    private String caption;
    private List<String> choices;
    private String referenceMainType;

    /**
     * 
     * @return dynamic property's name
     */
    public String getName() {
        return name;
    }

    /**
     * 
     * @param name
     *            : dynamic property's name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 
     * @return dynamic property's value
     */
    public String getValue() {
        return value;
    }

    /**
     * 
     * @param value
     *            : dynamic property's value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * 
     * @param value
     *            : dynamic property's value
     */
    public void setDefaultValue(String value) {
        this.defaultValue = value;
    }

    /**
     * 
     * @return dynamic property's type
     */
    public String getType() {
        return type;
    }

    /**
     * 
     * @param type
     *            : dynamic property's type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 
     * @return dynamic property's caption
     */
    public String getCaption() {
        return caption;
    }

    /**
     * 
     * @param caption
     *            : dynamic property's caption
     */
    public void setCaption(String caption) {
        this.caption = caption;
    }

    /**
     * 
     * @return dynamic property's choices
     */
    public List<String> getChoices() {
        return choices;
    }

    /**
     * 
     * @param choices
     *            dynamic property's choices
     */
    public void setChoices(List<String> choices) {
        this.choices = choices;
    }

    /**
     * 
     * @return dynamic property's reference type
     */
    public String getReferenceMainType() {
        return referenceMainType;
    }

    /**
     * 
     * @param name
     *            : dynamic property's reference type
     */
    public void setReferenceMainType(String referenceMainType) {
        this.referenceMainType = referenceMainType;
    }

    public JsonElement toJson() {
        JsonElement jVal = null;
        if (value != null && isValueChanged()) {
            switch (type) {
                case DynPropertyConstants.MUTLICHOICE_TYPE:
                    JsonArray array = new JsonArray();
                    String[] valArr = value.split(",");
                    for (String val : valArr) {
                        if (!val.isEmpty()) {
                            array.add(new JsonPrimitive(val));
                        }
                    }
                    jVal = array;

                    break;
                case DynPropertyConstants.REFERENCE_TYPE:
                    JsonObject jRef = new JsonObject();
                    String[] splits = value.split(":");
                    if (splits.length > 1) {
                        JsonObject app = new JsonObject();
                        app.addProperty("name", splits[0].trim());
                        jRef.add("application", app);
                        jRef.addProperty("name", splits[1].trim());
                    } else {
                        jRef.addProperty("name", value);
                    }
                    jVal = jRef;
                    break;
                default:
                    jVal = new JsonPrimitive(value);
            }
        }
        return jVal;
    }

    private boolean isValueChanged() {
        String temp1 = (value == null ? "" : value);
        String temp2 = (defaultValue == null ? "" : defaultValue);
        return !temp1.equals(temp2);
    }
}
