package com.automic.ws.rest.model.dynamicprop;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/**
 * This class holds the dynamic properties for the given workflow/application/component and package. It also provides
 * the JSON conversion of the data.
 */
public class DynamicProperties {

    private List<DynamicProperty> application;
    private List<DynamicProperty> workflow;
    private List<DynamicProperty> pkg;
    private List<ComponentDynProp> component;

    /**
     * 
     * @return dynamic propetries of the application
     */
    public List<DynamicProperty> getApplication() {
        return application;
    }

    /**
     * 
     * @param application
     *            dynamic property of the application
     */
    public void setApplication(List<DynamicProperty> application) {
        this.application = application;
    }

    /**
     * 
     * @return dynamic property of the workflow
     */
    public List<DynamicProperty> getWorkflow() {
        return workflow;
    }

    /**
     * 
     * @param workflow
     *            dynamic property of the workflow
     */
    public void setWorkflow(List<DynamicProperty> workflow) {
        this.workflow = workflow;
    }

    /**
     * 
     * @return dynamic property of the package
     */
    public List<DynamicProperty> getPckage() {
        return pkg;
    }

    /**
     * 
     * @param pckage
     *            dynamic property of the package
     */
    public void setPckage(List<DynamicProperty> pckage) {
        this.pkg = pckage;
    }

    /**
     * 
     * @return dynamic property of the component
     */
    public List<ComponentDynProp> getComponent() {
        return component;
    }

    public void setComponent(List<ComponentDynProp> comps) {
        this.component = comps;
    }

    public DynamicProperty getAppDynProperty(String propName) {
        for (DynamicProperty dp : getApplication()) {
            if (propName.equals(dp.getName())) {
                return dp;
            }
        }
        return null;
    }

    public DynamicProperty getWfDynProperty(String propName) {
        for (DynamicProperty dp : getWorkflow()) {
            if (propName.equals(dp.getName())) {
                return dp;
            }
        }
        return null;
    }

    public DynamicProperty getPkgDynProperty(String propName) {
        for (DynamicProperty dp : getPckage()) {
            if (propName.equals(dp.getName())) {
                return dp;
            }
        }
        return null;
    }

    public DynamicProperty getCompDynProperty(String compName, String propName) {
        for (ComponentDynProp compdp : getComponent()) {
            if (compName.equals(compdp.getCompName())) {
                for (DynamicProperty dp : compdp.getProperty()) {
                    if (propName.equals(dp.getName())) {
                        return dp;
                    }
                }
                break;
            }
        }
        return null;
    }

    public DynamicProperties merge(DynamicProperties uiDynamicProperties) {
        DynamicProperties dynProps = new DynamicProperties();
        if (uiDynamicProperties.getWorkflow() != null) {
            List<DynamicProperty> properties = new ArrayList<DynamicProperty>();
            for (DynamicProperty prop : uiDynamicProperties.getWorkflow()) {
                DynamicProperty temp = getWfDynProperty(prop.getName());
                temp.setValue(prop.getValue());
                properties.add(temp);
            }
            dynProps.setWorkflow(properties);
        }

        if (uiDynamicProperties.getApplication() != null) {
            List<DynamicProperty> properties = new ArrayList<DynamicProperty>();
            for (DynamicProperty prop : uiDynamicProperties.getApplication()) {
                DynamicProperty temp = getAppDynProperty(prop.getName());
                temp.setValue(prop.getValue());
                properties.add(temp);
            }
            dynProps.setApplication(properties);
        }

        if (uiDynamicProperties.getPckage() != null) {
            List<DynamicProperty> properties = new ArrayList<DynamicProperty>();
            for (DynamicProperty prop : uiDynamicProperties.getPckage()) {
                DynamicProperty temp = getPkgDynProperty(prop.getName());
                temp.setValue(prop.getValue());
                properties.add(temp);
            }
            dynProps.setPckage(properties);
        }

        if (uiDynamicProperties.getComponent() != null) {
            List<ComponentDynProp> compDynProperties = new ArrayList<ComponentDynProp>();
            for (ComponentDynProp prop : uiDynamicProperties.getComponent()) {
                List<DynamicProperty> dynamicProp = prop.getProperty();
                List<DynamicProperty> properties = new ArrayList<DynamicProperty>();
                for (DynamicProperty dynProp : dynamicProp) {
                    DynamicProperty temp = getCompDynProperty(prop.getCompName(), dynProp.getName());
                    temp.setValue(dynProp.getValue());
                    properties.add(temp);
                }
                ComponentDynProp compTemp = new ComponentDynProp();
                compTemp.setCompName(prop.getCompName());
                compTemp.setProperty(properties);
                compDynProperties.add(compTemp);
            }
            dynProps.setComponent(compDynProperties);
        }
        return dynProps;
    }

    public JsonObject toJson() {
        JsonObject overridesJson = new JsonObject();
        JsonObject compObj = null;

        if (null != component && component.size() > 0) {
            for (ComponentDynProp compProp : component) {
                JsonElement jVal = compProp.toJson();
                if (jVal != null) {
                    if (compObj == null) {
                        compObj = new JsonObject();
                    }
                    compObj.add(compProp.getCompName(), jVal);
                }

            }
            if (compObj != null) {
                overridesJson.add("components", compObj);
            }
        }

        if (null != application && application.size() > 0) {
            JsonObject jObj = DynamicPropertyParser.createJson(application);
            if (jObj != null) {
                overridesJson.add("application", jObj);
            }
        }
        if (null != workflow && workflow.size() > 0) {
            JsonObject jObj = DynamicPropertyParser.createJson(workflow);
            if (jObj != null) {
                overridesJson.add("workflow", jObj);
            }
        }
        if (null != pkg && pkg.size() > 0) {
            JsonObject jObj = DynamicPropertyParser.createJson(pkg);
            if (jObj != null) {
                overridesJson.add("package", jObj);
            }
        }
        
        return overridesJson;

    }
}
