package com.automic.ws.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.httpclient.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.automic.util.AraProperties;
import com.automic.ws.rest.filter.GenericResponseFilter;
import com.automic.ws.rest.model.ExecutionResponse;
import com.automic.ws.rest.model.dynamicprop.ComponentDynProp;
import com.automic.ws.rest.model.dynamicprop.DynamicProperties;
import com.automic.ws.rest.model.dynamicprop.DynamicProperty;
import com.automic.ws.rest.model.dynamicprop.DynamicPropertyParser;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.core.util.MultivaluedMapImpl;

/**
 * Abstract Service common to both General and Deployment Workflows
 *
 */
public abstract class ARARestWebService implements AutoCloseable {

    public static final String MAX_RESULTS = "max_results";
    public static final String MAX_RESULT_COUNT = "1000";
    protected static final String WORKFLOW = "workflows";
    protected static final String QUEUE = "queues";

    private static final Logger LOGGER = LoggerFactory.getLogger(ARARestWebService.class);
    private static final String REST_API = AraProperties.getInstance().getProperty("AraRestEndpoint");

    private String araBaseURL;
    private Client client;

    // constants for query parameters

    public ARARestWebService(String araBaseUrl, String username, String password) {
        this.araBaseURL = araBaseUrl;
        client = Client.create(getClientConfig());
        client.addFilter(new HTTPBasicAuthFilter(username, password));
        client.addFilter(new GenericResponseFilter());
        LOGGER.info("Client initialized..");
    }

    // Get Client Config
    private ClientConfig getClientConfig() {
        ClientConfig config = new DefaultClientConfig();
        config.getProperties().put(ClientConfig.PROPERTY_CONNECT_TIMEOUT,
                Integer.valueOf(AraProperties.getInstance().getProperty("connectionTimeOut")));
        config.getProperties().put(ClientConfig.PROPERTY_READ_TIMEOUT,
                Integer.valueOf(AraProperties.getInstance().getProperty("readTimeOut")));
        return config;
    }

    public boolean checkRestEnabled() {
        WebResource webResource = client.resource(araBaseURL).path(REST_API).path(WORKFLOW)
                .queryParam(MAX_RESULTS, "1");
        LOGGER.info("Calling url " + webResource.getURI());

        ClientResponse response = webResource.accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
        // even if http status code is 200 we check if response content is json or not
        int status = response.getStatus();
        if (HttpStatus.SC_OK == status) {
            List<String> headerValues = response.getHeaders().get(HttpHeaders.CONTENT_TYPE);
            if (headerValues.get(0).contains(MediaType.APPLICATION_JSON)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get the list of entity like Workflow, Application, Package, profile as a {@link JsonObject}
     * 
     * @param araEntity
     * @param queryParams
     * @return an instance of a {@link JsonObject}
     */
    public JsonObject getAraEntity(String araEntity, MultivaluedMap<String, String> queryParams) {
        WebResource webResource = client.resource(araBaseURL).path(REST_API).path(araEntity);
        if (queryParams != null) {
            webResource = webResource.queryParams(queryParams);
        }
        LOGGER.info("Calling url " + webResource.getURI());
        ClientResponse response = webResource.accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
        JsonObject jsonResponse = new JsonParser().parse(response.getEntity(String.class)).getAsJsonObject();
        return jsonResponse;
    }

    /**
     * This method is used to get the users or usergroup from ARA.Inorder to get users pass "users" as maintype else
     * pass "usergroups"
     * 
     * @param maintype
     * @return It will return a List of string of users/usergroups
     */
    public List<String> getUsersOrUserGroups(String maintype) {
        List<String> userList = new ArrayList<>();
        maintype = "User".equals(maintype) ? "users" : "usergroups";
        MultivaluedMap<String, String> paramMap = new MultivaluedMapImpl();
        paramMap.add(MAX_RESULTS, MAX_RESULT_COUNT);

        JsonArray jDataArray = getAraEntity(maintype, paramMap).get("data").getAsJsonArray();

        for (JsonElement jsonElement : jDataArray) {
            JsonObject jObj = jsonElement.getAsJsonObject();
            userList.add(jObj.get("name").getAsString());
        }
        return userList;
    }

    /**
     * 
     * @return This method will return the list of string active queues.
     */
    public List<String> getActiveQueues() {
        List<String> queueList = new ArrayList<String>();
        MultivaluedMap<String, String> paramMap = new MultivaluedMapImpl();
        paramMap.add(MAX_RESULTS, MAX_RESULT_COUNT);
        paramMap.add("status", "Active");

        JsonArray jDataArray = getAraEntity("queues", paramMap).get("data").getAsJsonArray();
        for (JsonElement jsonElement : jDataArray) {
            JsonObject jObj = jsonElement.getAsJsonObject();
            queueList.add(jObj.get("name").getAsString());
        }
        return queueList;
    }

    /**
     * This method is used to retrieve the dynamic properties of workflow,application,component,package & profile. The
     * parameter workflowName is mandatory.Boolean variable isAppDeployment is false for general type workflow else it
     * is true.
     * 
     * @param isAppDeployment
     * @param workflowName
     * @param application
     * @param pazkage
     * @param profile
     * @return List<DynamicProperties>
     */
    protected DynamicProperties getDynamicProperty(MultivaluedMap<String, String> queryParam) {

        DynamicProperties dproperties = new DynamicProperties();
        List<ComponentDynProp> compPropertyList = null;

        JsonObject responseJson = getAraEntity("prompts", queryParam);
        for (Map.Entry<String, JsonElement> entry : responseJson.entrySet()) {
            JsonObject jsonObj;
            String mainType = entry.getKey();
            switch (mainType) {
                case "components":
                    compPropertyList = new ArrayList<>();
                    jsonObj = entry.getValue().getAsJsonObject();
                    for (Map.Entry<String, JsonElement> jObj : jsonObj.entrySet()) {
                        ComponentDynProp compProperty = new ComponentDynProp();
                        compProperty.setCompName(jObj.getKey());
                        List<DynamicProperty> dpropertyList = DynamicPropertyParser.getPropertyList(jObj);
                        compProperty.setProperty(dpropertyList);
                        compPropertyList.add(compProperty);
                    }
                    dproperties.setComponent(compPropertyList);
                    break;

                case "application":
                    dproperties.setApplication(DynamicPropertyParser.getPropertyList(entry));
                    break;

                case "workflow":
                    dproperties.setWorkflow(DynamicPropertyParser.getPropertyList(entry));
                    break;

                case "package":
                    dproperties.setWorkflow(DynamicPropertyParser.getPropertyList(entry));
                    break;
            }
        }
        return dproperties;
    }

    public ExecutionResponse executeWorkflow(String jsonRequest) {
        ExecutionResponse execResponse = null;
        LOGGER.info("Executing request for Workflow ");
        WebResource webResource = client.resource(araBaseURL).path(REST_API).path("executions");

        LOGGER.info("Calling url " + webResource.getURI());
        ClientResponse response = webResource.entity(jsonRequest, MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON).post(ClientResponse.class);
        JsonObject responseJson = new JsonParser().parse(response.getEntity(String.class)).getAsJsonObject();

        execResponse = new ExecutionResponse(responseJson.get("id").toString(), responseJson.get("status").toString());
        return execResponse;
    }

    @Override
    public void close() {
        if (null != client) {
            try {
                client.destroy();
                LOGGER.info("Client Destroyed..");
            } catch (Exception e) {
                LOGGER.error("Error occured while destroying the client.");
            }
        }
    }

}
