package com.automic.ws.rest;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.ws.rs.core.MultivaluedMap;

import com.automic.util.CommonUtil;
import com.automic.ws.rest.model.dynamicprop.DynamicProperties;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sun.jersey.core.util.MultivaluedMapImpl;

/**
 * This class interacts with ARA Rest Web Service and provides the functionality which is required to execute the
 * Application Deployment workflow.
 */
public class ARADeploymentWorkflowService extends ARARestWebService {

    private static final String PACKAGE = "packages";
    private static final String PROFILE = "profiles";

    public ARADeploymentWorkflowService(String araBaseUrl, String username, String password) {
        super(araBaseUrl, username, password);
    }

    /**
     * This method will return set of application/provisioning type workflows.
     * 
     * @return Set <String>
     */
    public List<String> getApplicationWorkflowList(String applicationName) {
        MultivaluedMap<String, String> paramMap = new MultivaluedMapImpl();
        paramMap.add(MAX_RESULTS, MAX_RESULT_COUNT);
        paramMap.add("application.name", applicationName);
        JsonArray jDataArray = getAraEntity(WORKFLOW, paramMap).get("data").getAsJsonArray();
        List<String> workflowList = new ArrayList<>();
        for (JsonElement jsonElement : jDataArray) {
            JsonObject jObj = jsonElement.getAsJsonObject();
            String wkfType = jObj.get("custom_type").getAsJsonObject().get("name").getAsString();
            String wkfName = ("Provisioning".equals(wkfType)) ? jObj.get("name").getAsString() + " (*)" : jObj.get(
                    "name").getAsString();
            workflowList.add(wkfName);
        }
        return workflowList;
    }

    /**
     * This method will return the list of string workflows based on workflow type i.e general or
     * application/provisioning .
     */
    public List<String> getApplicationList() {
        MultivaluedMap<String, String> paramMap = new MultivaluedMapImpl();
        paramMap.add(MAX_RESULTS, "9999");
        JsonArray jDataArray = getAraEntity(WORKFLOW, paramMap).get("data").getAsJsonArray();
        Set<String> applicationSet = new HashSet<>();
        for (JsonElement jsonElement : jDataArray) {
            JsonElement jElement = jsonElement.getAsJsonObject().get("application");
            if (jElement != null) {
                applicationSet.add(jElement.getAsJsonObject().get("name").getAsString());
            }
        }
        List<String> appList = new ArrayList<>();
        appList.addAll(applicationSet);
        return appList;
    }

    /**
     * This method will return the list of Packages based on Application name.
     * 
     * @param applicationName
     *            name of the application
     * @return list of workflows
     */
    public List<String> getPackageList(String applicationName) {
        MultivaluedMap<String, String> paramMap = new MultivaluedMapImpl();
        paramMap.add(MAX_RESULTS, MAX_RESULT_COUNT);
        paramMap.add("application.name", applicationName);
        JsonArray jDataArray = getAraEntity(PACKAGE, paramMap).get("data").getAsJsonArray();
        return CommonUtil.getEntityList(jDataArray);
    }

    /**
     * This method will return the list of Profiles based on Application name.
     * 
     * @param applicationName
     *            name of the application
     * @return list of profiles
     */
    public List<String> getProfileList(String applicationName) {
        MultivaluedMap<String, String> paramMap = new MultivaluedMapImpl();
        paramMap.add(MAX_RESULTS, MAX_RESULT_COUNT);
        paramMap.add("application.name", applicationName);
        JsonArray jDataArray = getAraEntity(PROFILE, paramMap).get("data").getAsJsonArray();
        return CommonUtil.getEntityList(jDataArray);
    }

    /**
     * This method will return the list of string active queues based on profile name and application name.
     * 
     * @param profileName
     * @param applicationName
     * @return returns a list of active queues
     */
    public List<String> getProfileQueues(String profileName, String applicationName) {
        // if profile name and application name are empty or null we return an
        // empty
        if (profileName == null || profileName.isEmpty() || applicationName == null || applicationName.isEmpty()) {
            return new ArrayList<String>();
        }

        MultivaluedMap<String, String> paramMap = new MultivaluedMapImpl();
        paramMap.add(MAX_RESULTS, "1");
        paramMap.add("application.name", applicationName);
        paramMap.add("name", profileName);

        JsonArray jDataArray = getAraEntity(PROFILE, paramMap).get("data").getAsJsonArray();
        String profileId = null;
        for (JsonElement jsonElement : jDataArray) {
            JsonObject jObj = jsonElement.getAsJsonObject();
            profileId = jObj.get("id").getAsString();
        }

        List<String> queueList = null;
        if (profileId != null) {
            // getting profile based queue
            paramMap = new MultivaluedMapImpl();
            paramMap.add("status", "Active");
            paramMap.add(MAX_RESULTS, MAX_RESULT_COUNT);
            jDataArray = getAraEntity("profiles/" + profileId + "/queues", paramMap).get("data").getAsJsonArray();
            queueList = CommonUtil.getEntityList(jDataArray);
        }
        return queueList == null ? new ArrayList<String>() : queueList;
    }

    public DynamicProperties getApplicationDynamicProperties(String appName, String workflowName, String pkgName,
            String profile) {
        MultivaluedMap<String, String> queryParam = new MultivaluedMapImpl();
        queryParam.add("application", appName);
        
        String temp = workflowName;
        if (temp.endsWith(" (*)")) {
            temp = temp.replace(" (*)", "");
        }
        queryParam.add("workflow", temp);

        if (pkgName != null && !pkgName.isEmpty()) {
            queryParam.add("package", pkgName);
        }

        if (profile != null && !profile.isEmpty()) {
            queryParam.add("profile", profile);
        }
        return super.getDynamicProperty(queryParam);
    }

}
