package com.automic.ws.rest.model.workflow;

import com.automic.ws.rest.model.dynamicprop.DynamicProperties;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

/**
 *  This class holds the Application Deployment workflow data which will be used to execute the 
 *  corresponding workflow.
 */
public class DeploymentWorkflowProperties extends WorkflowProperties {

    private String appName;
    private String pkgName;
    private String profile;
    private String installationMode;    

    public DeploymentWorkflowProperties(String wf, String startAt, String manualConfirm,
            DynamicProperties dynamicProperties) {
        super(wf, startAt, manualConfirm, dynamicProperties);
    }

    public void setAppWfProperties(String appName, String pkgName, String profile, String installMode) {
        this.appName = appName;
        this.pkgName = pkgName;
        this.profile = profile;
        this.installationMode = installMode;
    }

    // prepare json object for execution of workflow
    @Override
    public String prepareRequestJson() {
        String workflowName = workflow;

        // boolean isProvisioning = false;
        JsonObject jObj = new JsonObject();
        // code for setting the dynamic properties
        if (dynamicProperties != null) {
            JsonObject overridesJson = dynamicProperties.toJson();
            jObj.add("overrides", overridesJson);
        }

        // for non-provisioning workflows
        if (workflowName.endsWith("(*)")) {
            workflowName = workflowName.replace(" (*)", "");
        } else {
            jObj.addProperty("deployment_profile", profile);

            if ("skip".equals(installationMode)) {
                jObj.addProperty("install_mode", "SkipExisting");
            }
        }
        // application name
        jObj.addProperty("application", appName);
        // workflow name
        jObj.addProperty("workflow", workflowName);
        // add package
        jObj.addProperty("package", pkgName);

        if (!WorkflowProperties.CONFIRM_NO.equals(manualConfirmation)) {
            jObj.addProperty("needs_manual_start", true);
            jObj.addProperty("manual_confirmer", userGroup);

        }

        if (WorkflowProperties.STATAT_EXECAT.equals(startAt)) {
            jObj.addProperty("planned_from", executeAt);
        } else if (WorkflowProperties.STARTAT_QUEUE.equals(startAt)) {
            if (null != queue && !queue.isEmpty()) {
                jObj.addProperty("queue", queue);
            }
        }
        Gson requestJson = new GsonBuilder().create();
        return requestJson.toJson(jObj);
    }

    /**
     * @return the appName
     */
    public String getAppName() {
        return appName;
    }

    /**
     * @return the pkgName
     */
    public String getPkgName() {
        return pkgName;
    }

    /**
     * @return the profile
     */
    public String getProfile() {
        return profile;
    }

    /**
     * @return the installationMode
     */
    public String getInstallationMode() {
        return installationMode;
    }

}
