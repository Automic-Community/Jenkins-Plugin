package com.automic.ws.rest.model.dynamicprop;

import java.util.List;

import com.google.gson.JsonElement;

/**
 * This class holds the dynamic properties for the given component. It also provides the method to generate
 * corresponding JSON format.
 */
public class ComponentDynProp {
    private String compName;
    private List<DynamicProperty> property;

    /**
     * 
     * @return name of the component
     */
    public String getCompName() {
        return compName;
    }

    /**
     * 
     * @param name
     *            of the component
     */
    public void setCompName(String compName) {
        this.compName = compName;
    }

    /**
     * 
     * @return list of dynamic props in a given component
     */
    public List<DynamicProperty> getProperty() {
        return property;
    }

    /**
     * 
     * @param property
     *            list of dynamic prop in a given component
     */
    public void setProperty(List<DynamicProperty> property) {
        this.property = property;
    }

    public JsonElement toJson() {
        return DynamicPropertyParser.createJson(property);
    }

}
