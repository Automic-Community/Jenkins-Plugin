/**
 * 
 */
package com.automic.ws.rest.exceptions;

/**
 * @author sumitsamson
 *
 */
public class RmWebServiceRuntimeException extends RuntimeException {

    private static final long serialVersionUID = -2727414165585891758L;

    private final int code;

    public RmWebServiceRuntimeException(int code, String message) {
        super(message);
        this.code = code;
    }

    public RmWebServiceRuntimeException(int code, String message, Exception e) {
        super(message, e);
        this.code = code;
    }

    public int getExceptionCode() {
        return code;
    }

}
