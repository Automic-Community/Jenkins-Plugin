package com.automic.ws.rest.model.workflow;

import com.automic.ws.rest.model.dynamicprop.DynamicProperties;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

/**
 * This class holds the General workflow data which will be used to execute the corresponding workflow.
 */

public class GeneralWorkflowProperties extends WorkflowProperties {

    public GeneralWorkflowProperties(String wf, String startAt, String manualConfirm,
            DynamicProperties dynamicProperties) {
        super(wf, startAt, manualConfirm, dynamicProperties);
    }

    // prepare json object for execution of workflow
    @Override
    public String prepareRequestJson() {

        // boolean isProvisioning = false;
        JsonObject jObj = new JsonObject();
        // code for setting the dynamic properties
        if (dynamicProperties != null) {
            JsonObject overridesJson = dynamicProperties.toJson();
            jObj.add("overrides", overridesJson);
        }

        jObj.addProperty("workflow", workflow);

        if (!WorkflowProperties.CONFIRM_NO.equals(manualConfirmation)) {
            jObj.addProperty("needs_manual_start", true);
            jObj.addProperty("manual_confirmer", userGroup);

        }

        if (WorkflowProperties.STATAT_EXECAT.equals(startAt)) {
            jObj.addProperty("planned_from", executeAt);
        } else if (WorkflowProperties.STARTAT_QUEUE.equals(startAt)) {
            if (null != queue && !queue.isEmpty()) {
                jObj.addProperty("queue", queue);
            }
        }
        Gson requestJson = new GsonBuilder().create();
        return requestJson.toJson(jObj);
    }

}
