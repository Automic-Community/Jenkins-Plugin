package com.automic.ws.rest;

import java.util.List;

import javax.ws.rs.core.MultivaluedMap;

import com.automic.util.CommonUtil;
import com.automic.ws.rest.model.dynamicprop.DynamicProperties;
import com.google.gson.JsonArray;
import com.sun.jersey.core.util.MultivaluedMapImpl;

/**
 * This class interacts with ARA Rest Web Service and provides the functionality which is required to execute the
 * General Deployment workflow.
 */
public class ARAGeneralWorkflowService extends ARARestWebService {

    public ARAGeneralWorkflowService(String araBaseUrl, String username, String password) {
        super(araBaseUrl, username, password);
    }

    /**
     * This method will return set of general workflows.
     * 
     * @return List <String>
     */
    public List<String> getGeneralWorkflowList() {
        MultivaluedMap<String, String> paramMap = new MultivaluedMapImpl();
        paramMap.add(MAX_RESULTS, MAX_RESULT_COUNT);
        paramMap.add("custom_type.name", "general");
        JsonArray jDataArray = getAraEntity("workflows", paramMap).get("data").getAsJsonArray();
        return CommonUtil.getEntityList(jDataArray);
    }

    public DynamicProperties getGeneralDynamicProperties(String workflowName) {
        MultivaluedMap<String, String> queryParam = new MultivaluedMapImpl();
        queryParam.add("workflow", workflowName);
        return getDynamicProperty(queryParam);
    }
}
