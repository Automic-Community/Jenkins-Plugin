package com.automic.ws.rest.model.workflow;

import com.automic.ws.rest.model.dynamicprop.DynamicProperties;

/**
 * This class contains common workflow properties and provides abstraction for generation of JSON data.
 * Further JSON data can be used to execute General as well as Application workflow.
 */
public abstract class WorkflowProperties {
    
    public static final String STARTAT_NOW = "now";
    public static final String STARTAT_QUEUE = "queue";
    public static final String STATAT_EXECAT = "at";
    
    public static final String CONFIRM_NO = "no";
    public static final String CONFIRM_USER = "User";
    public static final String CONFIRM_USRGRP = "UserGroup";


    String workflow;
    String startAt;
    String executeAt;
    String queue;
    String manualConfirmation;
    String userGroup;

    DynamicProperties dynamicProperties;

    public WorkflowProperties(String wf, String startAt, String manualConfirm, DynamicProperties dynamicProperties) {
        this.workflow = wf;
        this.startAt = startAt;
        this.manualConfirmation = manualConfirm;
        this.dynamicProperties = dynamicProperties;
    }

    /**
     * 
     * @return the workflow
     */
    public String getWorkflow() {
        return workflow;
    }

    /**
     * 
     * @return the startAt parameter
     */
    public String getStartAt() {
        return startAt;
    }

    /**
     * @return the executeAt
     */
    public String getExecuteAt() {
        return executeAt;
    }

    /**
     * @param execAt
     */
    public void setExecuteAt(String execAt) {
        this.executeAt = execAt;
    }

    /**
     * @return the queue
     */
    public String getQueue() {
        return queue;
    }

    /**
     * @param queue
     */
    public void setQueue(String queue) {
        this.queue = queue;
    }

    /**
     * @return the manualConfirmation
     */
    public String getManualConfirmation() {
        return manualConfirmation;
    }

    /**
     * @return the user/group
     */
    public String getUserGroup() {
        return userGroup;
    }

    /**
     * @param useGroup
     */
    public void setUserGroup(String userGroup) {
        this.userGroup = userGroup;
    }

    /**
     * @return the dynamicProperties
     */
    public DynamicProperties getDynamicProperties() {
        return dynamicProperties;
    }

    public abstract String prepareRequestJson();

}
