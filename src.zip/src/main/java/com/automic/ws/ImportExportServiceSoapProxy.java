package com.automic.ws;

public class ImportExportServiceSoapProxy implements com.automic.ws.ImportExportServiceSoap {
  private String _endpoint = null;
  private com.automic.ws.ImportExportServiceSoap importExportServiceSoap = null;
  
  public ImportExportServiceSoapProxy() {
    _initImportExportServiceSoapProxy();
  }
  
  public ImportExportServiceSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initImportExportServiceSoapProxy();
  }
  
  private void _initImportExportServiceSoapProxy() {
    try {
      importExportServiceSoap = (new com.automic.ws.ImportExportServiceLocator()).getImportExportServiceSoap();
      if (importExportServiceSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)importExportServiceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)importExportServiceSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (importExportServiceSoap != null)
      ((javax.xml.rpc.Stub)importExportServiceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.automic.ws.ImportExportServiceSoap getImportExportServiceSoap() {
    if (importExportServiceSoap == null)
      _initImportExportServiceSoapProxy();
    return importExportServiceSoap;
  }
  
  public com.automic.ws.Result export(java.lang.String username, java.lang.String password, java.lang.String mainType, java.lang.String customType, int begin, int count, java.lang.String format, java.lang.String[] properties, java.lang.String startDate, java.lang.String endDate, java.lang.String[] conditions) throws java.rmi.RemoteException{
    if (importExportServiceSoap == null)
      _initImportExportServiceSoapProxy();
    return importExportServiceSoap.export(username, password, mainType, customType, begin, count, format, properties, startDate, endDate, conditions);
  }
  
  public com.automic.ws.Result deepExport(java.lang.String username, java.lang.String password, java.lang.String mainType, java.lang.String customType, int begin, int count, java.lang.String startDate, java.lang.String endDate, java.lang.String[] conditions) throws java.rmi.RemoteException{
    if (importExportServiceSoap == null)
      _initImportExportServiceSoapProxy();
    return importExportServiceSoap.deepExport(username, password, mainType, customType, begin, count, startDate, endDate, conditions);
  }
  
  public com.automic.ws.Result _import(java.lang.String username, java.lang.String password, java.lang.String mainType, java.lang.String fomat, boolean failOnError, java.lang.String data) throws java.rmi.RemoteException{
    if (importExportServiceSoap == null)
      _initImportExportServiceSoapProxy();
    return importExportServiceSoap._import(username, password, mainType, fomat, failOnError, data);
  }
  
  public com.automic.ws.Result deepImport(java.lang.String username, java.lang.String password, java.lang.String mainType, boolean failOnError, java.lang.String data) throws java.rmi.RemoteException{
    if (importExportServiceSoap == null)
      _initImportExportServiceSoapProxy();
    return importExportServiceSoap.deepImport(username, password, mainType, failOnError, data);
  }
  
  public com.automic.ws.Result delete(java.lang.String username, java.lang.String password, java.lang.String mainType, java.lang.String fomat, boolean failOnError, java.lang.String data) throws java.rmi.RemoteException{
    if (importExportServiceSoap == null)
      _initImportExportServiceSoapProxy();
    return importExportServiceSoap.delete(username, password, mainType, fomat, failOnError, data);
  }
  
  public com.automic.ws.Result getStatus(java.lang.String token) throws java.rmi.RemoteException{
    if (importExportServiceSoap == null)
      _initImportExportServiceSoapProxy();
    return importExportServiceSoap.getStatus(token);
  }
  
  public com.automic.ws.Result testCsv(java.lang.String username, java.lang.String password, java.lang.String mainType, java.lang.String[] properties) throws java.rmi.RemoteException{
    if (importExportServiceSoap == null)
      _initImportExportServiceSoapProxy();
    return importExportServiceSoap.testCsv(username, password, mainType, properties);
  }
  
  
}