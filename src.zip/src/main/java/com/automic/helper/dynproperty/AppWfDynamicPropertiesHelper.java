package com.automic.helper.dynproperty;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.automic.ws.rest.ARADeploymentWorkflowService;
import com.automic.ws.rest.model.dynamicprop.ComponentDynProp;
import com.automic.ws.rest.model.dynamicprop.DynamicProperties;
import com.automic.ws.rest.model.dynamicprop.DynamicProperty;

/**
 * This class acts as helper class and provide convenient methods to UI for managing Dynamic properties for Application
 * Deployment workflow.
 */

public class AppWfDynamicPropertiesHelper extends DynamicPropertiesHelper {

    private static final String APPLICATION = "Application";
    private static final String COMPONENT = "Component";
    private static final String PKG = "Package";
    private static final String WORKFLOW = "Workflow";

    private String app;
    private String workflow;
    private String pkg;
    private String profile;
    private String key;
    private DynamicPropertiesCache cache;

    public AppWfDynamicPropertiesHelper(String url, String user, String password, DynamicPropertiesCache cache,
            String app, String workflow, String pkg, String profile) {
        super(url, user, password);
        this.cache = cache;
        this.app = app;        
        this.workflow = workflow;
        this.pkg = pkg;
        this.profile = profile;
        StringBuilder sb = new StringBuilder();
        sb.append(url).append(user).append(app).append(workflow).append(pkg).append(profile);
        this.key = sb.toString();
    }

    @Override
    DynamicProperties loadDynPropsFromARA() {
        try (ARADeploymentWorkflowService service = new ARADeploymentWorkflowService(url, user, password)) {
            String pkgType = pkg.indexOf("$") != -1 ? null : pkg;
            return service.getApplicationDynamicProperties(app, workflow, pkgType, profile);
        }
    }

    @Override
    public List<String> getDynPropertyNames() {
        List<String> propertyNames = new ArrayList<>();
        DynamicProperties dproperties = cache.getDynProperties(key, this);

        // get all the application related dynamic properties
        List<DynamicProperty> appDProperty = dproperties.getApplication();
        if (appDProperty != null) {
            for (DynamicProperty dp : appDProperty) {
                propertyNames.add(buildUIPropertyName(APPLICATION, dp.getName(), null));
            }
        }

        // get all the component related dynamic property
        List<ComponentDynProp> compDProperty = dproperties.getComponent();
        if (compDProperty != null) {
            for (ComponentDynProp compDP : compDProperty) {
                List<DynamicProperty> dprop = compDP.getProperty();
                if (dprop != null) {
                    for (DynamicProperty dp : dprop) {
                        propertyNames.add(buildUIPropertyName(COMPONENT, dp.getName(), compDP.getCompName()));
                    }
                }
            }
        }

        // get all the workflow related dynamic properties
        List<DynamicProperty> workflowDProperty = dproperties.getWorkflow();
        if (workflowDProperty != null) {
            for (DynamicProperty dp : workflowDProperty) {
                propertyNames.add(buildUIPropertyName(WORKFLOW, dp.getName(), null));
            }
        }

        // get all the package related dynamic properties
        List<DynamicProperty> packageDProperty = dproperties.getPckage();
        if (packageDProperty != null) {
            for (DynamicProperty dp : packageDProperty) {
                propertyNames.add(buildUIPropertyName(PKG, dp.getName(), null));
            }
        }
        return propertyNames;
    }

    @Override
    public boolean isDynamicPropetiesAvailable() {
        DynamicProperties dproperties = cache.getDynProperties(key, this);
        boolean isAvailable = (dproperties.getApplication() != null && dproperties.getApplication().size() != 0);

        if (!isAvailable) {
            isAvailable = (dproperties.getWorkflow() != null && dproperties.getWorkflow().size() != 0);
        }

        if (!isAvailable) {
            isAvailable = (dproperties.getComponent() != null && dproperties.getComponent().size() != 0);
        }

        if (!isAvailable) {
            isAvailable = (dproperties.getPckage() != null && dproperties.getPckage().size() != 0);
        }

        return isAvailable;
    }

    @Override
    public List<String> getReferenceProperties(String referenceMainType) {
        try (ARADeploymentWorkflowService service = new ARADeploymentWorkflowService(url, user, password)) {
            return ReferencePropertiesHelper.getReferenceProperties(service, referenceMainType);
        }
    }

    public static DynamicProperties getDynamicProperty(Map<String, String> properties) {
        UIProperty uiproperty = null;

        List<ComponentDynProp> componentList = null;
        ComponentDynProp compDP = null;

        List<DynamicProperty> applicationList = null;
        List<DynamicProperty> workflowList = null;
        List<DynamicProperty> packageList = null;

        Map<String, List<DynamicProperty>> compMap = new HashMap<>();

        for (Map.Entry<String, String> entry : properties.entrySet()) {
            uiproperty = buildUIProperty(entry.getKey());
            switch (uiproperty.getMainType()) {
                case APPLICATION:
                    applicationList = addDynamicProp(uiproperty, applicationList, entry.getValue());
                    break;
                case COMPONENT:
                    String componentName = uiproperty.getCompName();
                    List<DynamicProperty> dpList = compMap.get(componentName);                    
                    dpList = addDynamicProp(uiproperty, dpList, entry.getValue());
                    compMap.put(componentName, dpList);
                    break;
                case WORKFLOW:
                    workflowList = addDynamicProp(uiproperty, workflowList, entry.getValue());
                    break;
                case PKG:
                    packageList = addDynamicProp(uiproperty, packageList, entry.getValue());
                    break;
            }
        }

        DynamicProperties dynamicProp = new DynamicProperties();
        if (applicationList != null) {
            dynamicProp.setApplication(applicationList);
        }

        if (workflowList != null) {
            dynamicProp.setWorkflow(workflowList);
        }

        if (packageList != null) {
            dynamicProp.setPckage(packageList);
        }

        if (!compMap.isEmpty()) {
            componentList = new ArrayList<>();
            for (Map.Entry<String, List<DynamicProperty>> entry : compMap.entrySet()) {
                compDP = new ComponentDynProp();
                compDP.setCompName(entry.getKey());
                compDP.setProperty(entry.getValue());
                componentList.add(compDP);
            }
            dynamicProp.setComponent(componentList);
        }
        return dynamicProp;
    }

    private static List<DynamicProperty> addDynamicProp(UIProperty uiproperty, List<DynamicProperty> dpList,
            String value) {
        DynamicProperty dp = new DynamicProperty();
        dp.setName(uiproperty.getName());
        dp.setValue(value);
        if (dpList == null) {
            dpList = new ArrayList<>();
        }
        dpList.add(dp);
        return dpList;
    }

    @Override
    public DynamicProperty getDynamicProperty(String dynPropName) {
        DynamicProperties dproperties = cache.getDynProperties(key, this);
        UIProperty uiproperty = buildUIProperty(dynPropName);
        DynamicProperty dp = null;
        switch (uiproperty.getMainType()) {
            case APPLICATION:
                dp = dproperties.getAppDynProperty(uiproperty.getName());
                break;
            case COMPONENT:
                dp = dproperties.getCompDynProperty(uiproperty.getCompName(), uiproperty.getName());
                break;
            case WORKFLOW:
                dp = dproperties.getWfDynProperty(uiproperty.getName());
                break;
            case PKG:
                dp = dproperties.getPkgDynProperty(uiproperty.getName());
                break;
        }
        return dp;
    }

    private String buildUIPropertyName(String mainType, String name, String compName) {
        StringBuilder propertyName = new StringBuilder();
        propertyName.append(mainType).append("  :  ");
        if (compName != null) {
            propertyName.append(compName).append("  :  ");
        }
        propertyName.append(name);
        return propertyName.toString();
    }

    private static UIProperty buildUIProperty(String propName) {
        UIProperty uiProp = null;
        String[] names = propName.split(":");
        if (names.length == 3) {
            uiProp = new UIProperty(names[0].trim(), names[2].trim(), names[1].trim());
        } else if (names.length == 2) {
            uiProp = new UIProperty(names[0].trim(), names[1].trim());
        }
        return uiProp;
    }

    private static class UIProperty {
        private String mainType;
        private String compName;
        private String name;

        public UIProperty(String mainType, String name) {
            this.mainType = mainType;
            this.name = name;
        }

        public UIProperty(String mainType, String name, String compName) {
            this.mainType = mainType;
            this.name = name;
            this.compName = compName;
        }

        public String getMainType() {
            return mainType;
        }

        public String getName() {
            return name;
        }

        public String getCompName() {
            return compName;
        }
    }

}
