package com.automic.helper.dynproperty;

import java.util.ArrayList;
import java.util.List;

import com.automic.constants.DynPropertyConstants;
import com.automic.util.CommonUtil;
import com.automic.ws.rest.model.dynamicprop.DynamicProperties;
import com.automic.ws.rest.model.dynamicprop.DynamicProperty;

public abstract class DynamicPropertiesHelper {

    protected final String url;
    protected final String user;
    protected final String password;

    public DynamicPropertiesHelper(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.password = password;
    }

    public abstract boolean isDynamicPropetiesAvailable();

    public abstract List<String> getDynPropertyNames();
    
    public String getDynPropertyDefaultValue(String dynPropName) {
        return getDynamicProperty(dynPropName).getValue();
    }

    abstract DynamicProperties loadDynPropsFromARA();

    public String getDynPropertyInfo(String dynPropName) {
        DynamicProperty prop = getDynamicProperty(dynPropName);
        StringBuilder propInfo = new StringBuilder();
        if (CommonUtil.isNotEmpty(prop.getCaption())) {
            propInfo.append("Caption :").append(prop.getCaption()).append(", ");
        }
        propInfo.append("Property Type :").append(prop.getType());
        return propInfo.toString();
    }
    
    public List<String> getDynPropertyValues(String dynPropName) {
        DynamicProperty prop = getDynamicProperty(dynPropName);
        List<String> propertyValues = null;
        if (DynPropertyConstants.REFERENCE_TYPE.equals(prop.getType())) {
            propertyValues = getReferenceProperties(prop.getReferenceMainType());

        } else {
            propertyValues = prop.getChoices();
        }
        return propertyValues == null ? new ArrayList<String>() : propertyValues;
    }
    
    protected abstract List<String> getReferenceProperties(String referenceMainType);

    protected abstract DynamicProperty getDynamicProperty(String dynPropName);

}
