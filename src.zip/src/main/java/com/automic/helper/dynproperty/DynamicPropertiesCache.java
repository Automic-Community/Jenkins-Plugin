package com.automic.helper.dynproperty;

import java.util.Hashtable;

import com.automic.ws.rest.model.dynamicprop.DynamicProperties;

/**
 * This class provides the caching of dynamic properties. As far as caller holds the object of this class, they can
 * retrieve the cached dynamic properties. If dynamic properties are not already loaded. this will load the dynamic
 * properties from ARA as well. This will not hold more than one instance of dynamic properties in cache as we keep this
 * object in user's http session.
 */
public class DynamicPropertiesCache {

    private static final int MAX_SIZE = 5;
    private final Hashtable<String, DynamicProperties> dynProperties;

    public DynamicPropertiesCache() {
        dynProperties = new Hashtable<String, DynamicProperties>();
    }

    public DynamicProperties getDynProperties(final String key, DynamicPropertiesHelper helper) {
        DynamicProperties props = dynProperties.get(key);
        if (props == null) {
            synchronized (key.intern()) {
                props = dynProperties.get(key);
                if (props == null) {
                    props = helper.loadDynPropsFromARA();
                    if (dynProperties.size() > MAX_SIZE) {
                        dynProperties.clear();
                    }
                    dynProperties.put(key, props);
                }
            }
        }
        return props;
    }

}
