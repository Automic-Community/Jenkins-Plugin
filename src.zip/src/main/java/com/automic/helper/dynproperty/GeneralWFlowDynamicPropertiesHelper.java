package com.automic.helper.dynproperty;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.automic.ws.rest.ARAGeneralWorkflowService;
import com.automic.ws.rest.model.dynamicprop.DynamicProperties;
import com.automic.ws.rest.model.dynamicprop.DynamicProperty;

/**
 * This class acts as helper class and provide convenient methods to UI for managing Dynamic properties for General
 * workflow.
 */
public class GeneralWFlowDynamicPropertiesHelper extends DynamicPropertiesHelper {

    private DynamicPropertiesCache cache;
    private String workflow;
    private String key;

    public GeneralWFlowDynamicPropertiesHelper(String url, String user, String password, DynamicPropertiesCache cache,
            String workflow) {
        super(url, user, password);
        this.cache = cache;
        this.workflow = workflow;
        StringBuilder sb = new StringBuilder();
        sb.append(url).append(user).append(workflow);
        key = sb.toString();
    }

    @Override
    public List<String> getDynPropertyNames() {
        List<String> propertyNames = new ArrayList<>();
        DynamicProperties dproperties = cache.getDynProperties(key, this);
        List<DynamicProperty> workflowDProperty = dproperties.getWorkflow();
        if (workflowDProperty != null) {
            for (DynamicProperty dp : workflowDProperty) {
                propertyNames.add(dp.getName());
            }
        }
        return propertyNames;
    }

    @Override
    public boolean isDynamicPropetiesAvailable() {
        DynamicProperties dproperties = cache.getDynProperties(key, this);
        return dproperties.getWorkflow() != null && dproperties.getWorkflow().size() != 0;
    }

    @Override
    DynamicProperties loadDynPropsFromARA() {
        try (ARAGeneralWorkflowService service = new ARAGeneralWorkflowService(url, user, password)) {
            return service.getGeneralDynamicProperties(workflow);
        }
    }

    @Override
    public List<String> getReferenceProperties(String referenceMainType) {
        try (ARAGeneralWorkflowService service = new ARAGeneralWorkflowService(url, user, password)) {
            return ReferencePropertiesHelper.getReferenceProperties(service, referenceMainType);
        }
    }

    @Override
    public DynamicProperty getDynamicProperty(String dynPropName) {
        DynamicProperties dproperties = cache.getDynProperties(key, this);
        return dproperties.getWfDynProperty(dynPropName);
    }

    public static DynamicProperties getDynamicProperty(Map<String, String> properties) {
        DynamicProperties dynamicProp = null;
        List<DynamicProperty> workflowList = null;
        for (Map.Entry<String, String> entry : properties.entrySet()) {
            DynamicProperty wkflwDp = new DynamicProperty();
            wkflwDp.setName(entry.getKey());
            wkflwDp.setValue(entry.getValue());
            if (workflowList == null) {
                workflowList = new ArrayList<>();
            }
            workflowList.add(wkflwDp);
        }

        if (workflowList != null) {
            dynamicProp = new DynamicProperties();
            dynamicProp.setWorkflow(workflowList);
        }

        return dynamicProp;
    }

}
