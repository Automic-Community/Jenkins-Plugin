package com.automic.helper.dynproperty;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MultivaluedMap;

import com.automic.constants.DynPropertyConstants;
import com.automic.util.AraProperties;
import com.automic.util.CommonUtil;
import com.automic.ws.rest.ARARestWebService;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sun.jersey.core.util.MultivaluedMapImpl;

/**
 * This class provides utility methods to load the reference type data as defined in ARA. 
 *
 */
public class ReferencePropertiesHelper {

    public static List<String> getReferenceProperties(ARARestWebService service, String referenceMainType) {
        List<String> propertyValues = null;
        MultivaluedMap<String, String> paramMap = new MultivaluedMapImpl();
        paramMap.add(ARARestWebService.MAX_RESULTS, ARARestWebService.MAX_RESULT_COUNT);
        if (DynPropertyConstants.REFERENCETYPE_MEMBER.equals(referenceMainType)) {
            propertyValues = service.getUsersOrUserGroups("User");
            propertyValues.addAll(service.getUsersOrUserGroups("UserGroup"));
        } else if (AraProperties.getInstance().containsKey(referenceMainType)) {
            JsonObject jsonResponse = service.getAraEntity(AraProperties.getInstance().getProperty(referenceMainType),
                    paramMap);
            JsonArray jDataArray = jsonResponse.get("data").getAsJsonArray();
            propertyValues = CommonUtil.getEntityList(jDataArray);
            propertyValues = CommonUtil.getUniqueValues(propertyValues);
        }
        return propertyValues == null ? new ArrayList<String>() : propertyValues;
    }
}
