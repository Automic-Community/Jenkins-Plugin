package com.automic.jenkinsui.util;

import hudson.util.FormValidation;
import hudson.util.Secret;
import hudson.util.ListBoxModel;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.automic.helper.dynproperty.DynamicPropertiesCache;
import com.automic.util.JenkinsValidationUtility;
import com.automic.ws.rest.ARADeploymentWorkflowService;
import com.automic.ws.rest.model.workflow.WorkflowProperties;

/**
 * This class provides utility methods for performing common UI operations such as sorting.
 */

public class UIUtil {

    public static final String OPTION_PLEASE_SELECT = "-Please Select-";

    public static ListBoxModel sortedListModel(List<String> data, boolean confirmation) {
        Collections.sort(data);
        ListBoxModel list = new ListBoxModel();
        if (confirmation) {
            list.add(OPTION_PLEASE_SELECT);
        }
        for (String item : data) {
            list.add(item);
        }
        return list;
    }

    public static FormValidation testConnection(final String server, final String user, final Secret pass) {
        String serverTrimmed = server != null ? server.trim() : server;
        String userTrimmed = user != null ? user.trim() : user;
        String passwd = pass == null ? null : Secret.toString(pass);
        String errMsg = JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed);
        if (errMsg == null) {
            try (ARADeploymentWorkflowService ws = new ARADeploymentWorkflowService(serverTrimmed, userTrimmed, passwd)) {
                return ws.checkRestEnabled() ? FormValidation.ok("Login successful") : FormValidation
                        .error("Login failed. You might not be using compatible ARA version.");
            } catch (Exception e) {
                return FormValidation.error("Login failed. Reason - " + e.getMessage());
            }
        } else {
            return FormValidation.error("Login failed. Error Message [" + errMsg + "]");
        }
    }

    public static ListBoxModel getStartAtItems() {
        ListBoxModel items = new ListBoxModel();
        items.add("Now", WorkflowProperties.STARTAT_NOW);
        items.add("At", WorkflowProperties.STATAT_EXECAT);
        items.add("Queue", WorkflowProperties.STARTAT_QUEUE);
        return items;
    }

    public static FormValidation validateStartAt(String startAt, String value) {
        String errMsg = null;
        if (WorkflowProperties.STATAT_EXECAT.equals(startAt)) {
            String executionTime = value != null ? value.trim() : "";
            if (executionTime.indexOf("$") == -1) {
                errMsg = JenkinsValidationUtility.validateExecutionTime(executionTime);
            }
        }
        return errMsg == null ? FormValidation.ok() : FormValidation.error(errMsg);
    }

    public static ListBoxModel getManualConfirmationItems() {
        ListBoxModel items = new ListBoxModel();
        items.add("No", WorkflowProperties.CONFIRM_NO);
        items.add("User", WorkflowProperties.CONFIRM_USER);
        items.add("Group", WorkflowProperties.CONFIRM_USRGRP);
        return items;
    }

    public static DynamicPropertiesCache getCache(HttpSession session) {
        Object obj = session.getAttribute("CACHE_KEY");
        DynamicPropertiesCache cache = null;
        if (obj == null) {
            cache = new DynamicPropertiesCache();
            session.setAttribute("CACHE_KEY", cache);
        } else {
            cache = (DynamicPropertiesCache) obj;
        }
        return cache;
    }

}
