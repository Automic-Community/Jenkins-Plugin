package com.automic.constants;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/**
 * Defines constants used across Jenkins plugin classes.
 */
public final class JenkinsConstants {

    public static final int HTTP_NOTFOUND = 404;
    
    public static final Charset ENCODING = StandardCharsets.UTF_8;
    public static final String COMPARATOR_CONTAIN = "Contains";
    public static final String COMPARATOR_NOT_CONTAIN = "Does not contain";
    public static final String PCK_NAME = "[\\w\\d\\$\\.\\@\\#\\s\\-]+";
    public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String ARA_TIMEZONE = "UTC";
    public static final String FORM_DATE_FORMAT = "yyyy-MM-dd HH:mm";

    private JenkinsConstants() {
    }

}
