package com.automic.constants;

/**
 * This class contains reference type and corresponding main type related identifiers.
 */
public final class DynPropertyConstants {
    
    //Property Types
    public static final String MUTLICHOICE_TYPE = "MultiChoice";
    public static final String LIST_TYPE = "List";    
    public static final String SINGLECHOICE_TYPE = "SingleChoice";
    public static final String REFERENCE_TYPE = "Reference";
        
    //Reference main types
    public static final String REFERENCETYPE_PKG = "Package";
    public static final String REFERENCETYPE_MEMBER = "Member";

}
