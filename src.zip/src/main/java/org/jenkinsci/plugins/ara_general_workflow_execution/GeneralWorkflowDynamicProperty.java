package org.jenkinsci.plugins.ara_general_workflow_execution;

/**
 * Created with IntelliJ IDEA.
 * User: Administrator
 * Date: 7/18/13
 * Time: 12:05 PM
 * To change this template use File | Settings | File Templates.
 */
import hudson.Extension;
import hudson.RelativePath;
import hudson.model.Describable;
import hudson.model.Descriptor;
import hudson.util.ComboBoxModel;
import hudson.util.FormValidation;
import hudson.util.Secret;
import hudson.util.ListBoxModel;

import java.util.Collections;
import java.util.List;

import jenkins.model.Jenkins;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;
import org.kohsuke.stapler.Stapler;
import org.kohsuke.stapler.bind.JavaScriptMethod;

import com.automic.helper.dynproperty.DynamicPropertiesCache;
import com.automic.helper.dynproperty.GeneralWFlowDynamicPropertiesHelper;
import com.automic.jenkinsui.util.UIUtil;
import com.automic.util.CommonUtil;
import com.automic.util.JenkinsValidationUtility;

/**
 * 
 * @author Chris Johnson
 */
public class GeneralWorkflowDynamicProperty implements Describable<GeneralWorkflowDynamicProperty> {

    private final String propName;
    private final String propValue;

    @DataBoundConstructor
    public GeneralWorkflowDynamicProperty(String propName, String propValue) {
        this.propName = propName;
        this.propValue = propValue;
    }

    public String getPropName() {
        return propName;
    }

    public String getPropValue() {
        return propValue;
    }

    @SuppressWarnings("unchecked")
    public Descriptor<GeneralWorkflowDynamicProperty> getDescriptor() {
        return Jenkins.getInstance().getDescriptorOrDie(getClass());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Name=").append(propName).append(" Value=").append(propValue);
        return sb.toString();
    }

    public String validate() {
        if (!(CommonUtil.isNotEmpty(propName) && !UIUtil.OPTION_PLEASE_SELECT.equals(propName))) {
            return "Dynamic Property name is not provided";
        }
        return null;
    }

    /**
     * Defines descriptor class for each instance of Dynamic property.
     */
    @Extension
    public static class DescriptorImpl extends Descriptor<GeneralWorkflowDynamicProperty> {

        @Override
        public String getDisplayName() {
            return ""; // unused
        }

        @JavaScriptMethod
        public String getDynaPropValue(final String server, final String user, final Secret pass,
                final String workflow, final String property) {
            if (CommonUtil.isNotEmpty(property) && !UIUtil.OPTION_PLEASE_SELECT.equals(property)) {
                String serverTrimmed = server != null ? server.trim() : server;
                String userTrimmed = user != null ? user.trim() : user;
                String passwd = pass == null ? null : Secret.toString(pass);
                DynamicPropertiesCache dynamicPropCache = getCache();
                GeneralWFlowDynamicPropertiesHelper generalDynamicHelper = new GeneralWFlowDynamicPropertiesHelper(
                        serverTrimmed, userTrimmed, passwd, dynamicPropCache, workflow);
                return generalDynamicHelper.getDynPropertyDefaultValue(property);
            }
            return "";
        }

        public ListBoxModel doFillPropNameItems(
                @QueryParameter(value = "server") @RelativePath("..") final String server,
                @QueryParameter(value = "user") @RelativePath("..") final String user,
                @QueryParameter(value = "pass") @RelativePath("..") final Secret pass,
                @QueryParameter(value = "workflow") @RelativePath("..") final String workflow) {
            ListBoxModel items = null;
            if (CommonUtil.isNotEmpty(workflow)) {
                String serverTrimmed = server != null ? server.trim() : server;
                String userTrimmed = user != null ? user.trim() : user;
                String passwd = pass == null ? null : Secret.toString(pass);
                String errMsg = JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed);
                if (errMsg == null) {
                    DynamicPropertiesCache dynamicPropCache = getCache();
                    GeneralWFlowDynamicPropertiesHelper generalDynamicHelper = new GeneralWFlowDynamicPropertiesHelper(
                            serverTrimmed, userTrimmed, passwd, dynamicPropCache, workflow);
                    List<String> dynPropNames = generalDynamicHelper.getDynPropertyNames();
                    if (!dynPropNames.isEmpty()) {
                        items = UIUtil.sortedListModel(dynPropNames, true);
                    }
                }
            }
            return items == null ? new ListBoxModel() : items;
        }

        public FormValidation doCheckPropName(
                @QueryParameter(value = "server") @RelativePath("..") final String server,
                @QueryParameter(value = "user") @RelativePath("..") final String user,
                @QueryParameter(value = "pass") @RelativePath("..") final Secret pass,
                @QueryParameter(value = "workflow") @RelativePath("..") final String workflow,
                @QueryParameter("propName") final String propName) {
            if (CommonUtil.isNotEmpty(propName) && !UIUtil.OPTION_PLEASE_SELECT.equals(propName)) {
                String dynCaption = "";
                String serverTrimmed = server != null ? server.trim() : server;
                String userTrimmed = user != null ? user.trim() : user;
                String passwd = pass == null ? null : Secret.toString(pass);
                String errMsg = JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed);
                if (errMsg == null) {
                    DynamicPropertiesCache dynamicPropCache = getCache();
                    GeneralWFlowDynamicPropertiesHelper generalDynamicHelper = new GeneralWFlowDynamicPropertiesHelper(
                            serverTrimmed, userTrimmed, passwd, dynamicPropCache, workflow);
                    dynCaption = generalDynamicHelper.getDynPropertyInfo(propName);
                }
                if (CommonUtil.isNotEmpty(dynCaption)) {
                    return FormValidation.okWithMarkup(dynCaption);
                }
            }
            return FormValidation.ok();
        }

        public ComboBoxModel doFillPropValueItems(
                @QueryParameter(value = "server") @RelativePath("..") final String server,
                @QueryParameter(value = "user") @RelativePath("..") final String user,
                @QueryParameter(value = "pass") @RelativePath("..") final Secret pass,
                @QueryParameter(value = "workflow") @RelativePath("..") final String workflow,
                @QueryParameter("propName") final String propName) {
            ComboBoxModel items = new ComboBoxModel();
            if (CommonUtil.isNotEmpty(propName) && !UIUtil.OPTION_PLEASE_SELECT.equals(propName)) {
                String serverTrimmed = server != null ? server.trim() : server;
                String userTrimmed = user != null ? user.trim() : user;
                String passwd = pass == null ? null : Secret.toString(pass);
                String errMsg = JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed);
                if (errMsg == null) {
                    DynamicPropertiesCache dynamicPropCache = getCache();
                    GeneralWFlowDynamicPropertiesHelper generalDynamicHelper = new GeneralWFlowDynamicPropertiesHelper(
                            serverTrimmed, userTrimmed, passwd, dynamicPropCache, workflow);
                    List<String> propValueList = generalDynamicHelper.getDynPropertyValues(propName);
                    Collections.sort(propValueList);
                    items.addAll(propValueList);
                }
            }
            return items;
        }

        private synchronized DynamicPropertiesCache getCache() {
            return UIUtil.getCache(Stapler.getCurrentRequest().getSession());
        }
    }

}