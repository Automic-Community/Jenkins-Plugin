package org.jenkinsci.plugins.ara_general_workflow_execution;

import hudson.EnvVars;
import hudson.Extension;
import hudson.Launcher;
import hudson.Util;
import hudson.model.BuildListener;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.BuildStepMonitor;
import hudson.tasks.Publisher;
import hudson.tasks.Recorder;
import hudson.util.FormValidation;
import hudson.util.Secret;
import hudson.util.ListBoxModel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;
import org.kohsuke.stapler.Stapler;

import com.automic.helper.dynproperty.DynamicPropertiesCache;
import com.automic.helper.dynproperty.GeneralWFlowDynamicPropertiesHelper;
import com.automic.jenkinsui.util.UIUtil;
import com.automic.util.CommonUtil;
import com.automic.util.JenkinsValidationUtility;
import com.automic.ws.rest.ARAGeneralWorkflowService;
import com.automic.ws.rest.exceptions.RmWebServiceRuntimeException;
import com.automic.ws.rest.model.ExecutionResponse;
import com.automic.ws.rest.model.dynamicprop.DynamicProperties;
import com.automic.ws.rest.model.workflow.GeneralWorkflowProperties;
import com.automic.ws.rest.model.workflow.WorkflowProperties;

public class AraGeneralWorkflowExecProp extends Recorder {

    private String server;
    private String user;
    private Secret pass;
    private String workflow;
    private String startAt;
    private String executeAt;
    private String queue;
    private String manualConfirmation;
    private String userGroup;
    private List<GeneralWorkflowDynamicProperty> dynProps;

    @DataBoundConstructor
    public AraGeneralWorkflowExecProp(String server, String user, Secret pass, String workflow, String startAt,
            String executeAt, String queue, String manualConfirmation, String userGroup,
            List<GeneralWorkflowDynamicProperty> dynProps) {
        this.server = server;
        this.user = user;
        this.pass = pass;
        this.workflow = workflow;
        this.startAt = startAt;
        this.executeAt = executeAt;
        this.queue = queue;
        this.manualConfirmation = manualConfirmation;
        this.userGroup = userGroup;
        this.dynProps = dynProps;
    }

    @Override
    public BuildStepMonitor getRequiredMonitorService() {
        return BuildStepMonitor.NONE;
    }

    @Override
    public GeneralWorkflowDescriptor getDescriptor() {
        return (GeneralWorkflowDescriptor) super.getDescriptor();
    }

    @Override
    public boolean perform(AbstractBuild<?, ?> build, Launcher launcher, BuildListener listener)
            throws InterruptedException, IOException {

        // log ARA entity information
        listener.getLogger().println(toString());
        EnvVars envs = build.getEnvironment(listener);

        String tempServer = getServer() != null ? getServer().trim() : null;
        String tempUser = getUser() != null ? getUser().trim() : null;
        String passwd = getPass() == null ? null : Secret.toString(getPass());
        String tempExecTime = getExecuteAt() != null ? Util.replaceMacro(getExecuteAt().trim(), envs) : null;

        // Validate user input parameter
        List<String> errors = validate(tempServer, tempUser, tempExecTime);
        if (errors.size() > 0) {
            listener.getLogger().println("Error : Invalid input parameters provided. Error details: " + errors);
            return false;
        }

        try (ARAGeneralWorkflowService ws = new ARAGeneralWorkflowService(tempServer, tempUser, passwd)) {
            DynamicProperties araDynamicProperties = null;
            if (dynProps != null && dynProps.size() > 0) {
                Map<String, String> uiDynamicPropMap = new HashMap<>();
                for (GeneralWorkflowDynamicProperty prop : dynProps) {
                    String propValue = prop.getPropValue() != null ? Util
                            .replaceMacro(prop.getPropValue().trim(), envs) : null;
                    listener.getLogger().println("Dynamic Property " + prop.getPropName() + ":=" + propValue);
                    String temp = uiDynamicPropMap.put(prop.getPropName(), propValue);
                    if (temp != null) {
                        listener.getLogger().println(
                                "Warning : Duplicate Prompt property [" + prop.getPropName()
                                        + "] has been specified. Will override the value [" + propValue + "]");
                    }
                }
                DynamicProperties uiDynamicProperties = GeneralWFlowDynamicPropertiesHelper
                        .getDynamicProperty(uiDynamicPropMap);
                araDynamicProperties = ws.getGeneralDynamicProperties(getWorkflow());
                araDynamicProperties = araDynamicProperties.merge(uiDynamicProperties);
            }

            GeneralWorkflowProperties workflowExecution = new GeneralWorkflowProperties(getWorkflow(), getStartAt(),
                    getManualConfirmation(), araDynamicProperties);

            if (WorkflowProperties.STATAT_EXECAT.equals(getStartAt())) {
                workflowExecution.setExecuteAt(CommonUtil.convertToARADateFormat(tempExecTime));
            } else if (WorkflowProperties.STARTAT_QUEUE.equals(getStartAt())) {
                workflowExecution.setQueue(getQueue());
            }

            if (!WorkflowProperties.CONFIRM_NO.equals(getManualConfirmation())) {
                workflowExecution.setUserGroup(getUserGroup());
            }

            listener.getLogger().println("Executing ARA General Workflow : " + getWorkflow());
            listener.getLogger().println("Info : JSON Request :");
            String json = workflowExecution.prepareRequestJson();
            listener.getLogger().println(json);

            ExecutionResponse exeResponse = ws.executeWorkflow(json);
            listener.getLogger().println(
                    "Info : ARA General Workflow " + getWorkflow() + " executed successfully, " + exeResponse);
        } catch (Exception e) {
            String errMsg = JenkinsValidationUtility.checkCompatibleARA(e);
            if (errMsg != null) {
                listener.getLogger().println("Error: " + errMsg);
            }
            listener.getLogger().println(
                    "Error : Execution of general workflow[" + getWorkflow() + "] failed. Reason- " + e.getMessage());
            listener.getLogger().println("Error in performing build ID:" + build.getId());
            return false;
        }
        return true;
    }

    private List<String> validate(String tempServer, String tempUser, String executionTime) {
        List<String> errors = new ArrayList<String>();

        String errMsg = JenkinsValidationUtility.validateConnectionParameter(tempServer, tempUser);
        if (errMsg != null) {
            errors.add(errMsg);
        }

        if (!CommonUtil.isNotEmpty(getWorkflow())) {
            errors.add("Workflow name is not provided");
        }

        if (getDynProps() != null) {
            for (GeneralWorkflowDynamicProperty prop : getDynProps()) {
                String error = prop.validate();
                if (error != null) {
                    errors.add(error);
                    break;
                }
            }
        }

        if (WorkflowProperties.STARTAT_QUEUE.equals(getStartAt()) && !CommonUtil.isNotEmpty(getQueue())) {
            errors.add("Queue is not provided");
        }

        if (WorkflowProperties.STATAT_EXECAT.equals(getStartAt())) {
            errMsg = JenkinsValidationUtility.validateExecutionTime(executionTime);
            if (errMsg != null) {
                errors.add(errMsg);
            }
        }

        if (!WorkflowProperties.CONFIRM_NO.equals(getManualConfirmation()) && !CommonUtil.isNotEmpty(getUserGroup())) {
            errors.add("User/User Group is not provided");
        }
        return errors;
    }

    @Extension
    public static class GeneralWorkflowDescriptor extends BuildStepDescriptor<Publisher> {

        public FormValidation doCheckServer(@QueryParameter String value) throws IOException {
            String server = value != null ? value.trim() : value;
            String errMsg = JenkinsValidationUtility.validateServerURL(server);
            return errMsg == null ? FormValidation.ok() : FormValidation.error(errMsg);
        }

        public FormValidation doCheckUser(@QueryParameter String value) throws IOException {
            String usrTrimmed = value != null ? value.trim() : value;
            String errMsg = JenkinsValidationUtility.validateUserName(usrTrimmed);
            return errMsg == null ? FormValidation.ok() : FormValidation.error(errMsg);
        }

        public FormValidation doTestConnection(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass)
                throws IOException {
            return UIUtil.testConnection(server, user, pass);
        }

        public ListBoxModel doFillWorkflowItems(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass) {
            ListBoxModel items = null;
            try (ARAGeneralWorkflowService genWrkflwService = getRestWebService(server, user, pass)) {
                if (genWrkflwService != null) {
                    List<String> workflowList = genWrkflwService.getGeneralWorkflowList();
                    items = UIUtil.sortedListModel(workflowList, false);
                }
            }
            return items == null ? new ListBoxModel() : items;
        }

        public ListBoxModel doFillStartAtItems() {
            return UIUtil.getStartAtItems();
        }

        public FormValidation doCheckExecuteAt(@QueryParameter String value,
                @QueryParameter("startAt") final String startAt) throws IOException {
            return UIUtil.validateStartAt(startAt, value);
        }

        public ListBoxModel doFillQueueItems(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass,
                @QueryParameter("startAt") final String startAt) {
            ListBoxModel items = null;
            if (WorkflowProperties.STARTAT_QUEUE.equals(startAt)) {
                try (ARAGeneralWorkflowService genWrkflwService = getRestWebService(server, user, pass)) {
                    if (genWrkflwService != null) {
                        List<String> queueList = genWrkflwService.getActiveQueues();
                        items = UIUtil.sortedListModel(queueList, false);
                    }
                }
            }
            return items == null ? new ListBoxModel() : items;
        }

        public ListBoxModel doFillManualConfirmationItems() {
            return UIUtil.getManualConfirmationItems();
        }

        public ListBoxModel doFillUserGroupItems(@QueryParameter("server") String server,
                @QueryParameter("user") String user, @QueryParameter("pass") Secret pass,
                @QueryParameter("manualConfirmation") String manualConfirmation) {

            ListBoxModel items = null;
            if ((manualConfirmation != null) && (!WorkflowProperties.CONFIRM_NO.equals(manualConfirmation))) {
                try (ARAGeneralWorkflowService genWrkflwService = getRestWebService(server, user, pass)) {
                    if (genWrkflwService != null) {
                        List<String> userGroupList = genWrkflwService.getUsersOrUserGroups(manualConfirmation);
                        items = UIUtil.sortedListModel(userGroupList, false);
                    }
                } catch (Exception ex) {
                    items = new ListBoxModel();
                    items.add(user);
                }
            }
            return items == null ? new ListBoxModel() : items;
        }

        public FormValidation doCheckDynamicProperties(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass,
                @QueryParameter("workflow") final String workflow) throws IOException {

            String msg = "Necessary Parameters are not provided.";
            String serverTrimmed = server != null ? server.trim() : server;
            String userTrimmed = user != null ? user.trim() : user;
            String passwd = pass == null ? null : Secret.toString(pass);
            String errMsg = JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed);
            if (errMsg == null && null != workflow && !workflow.isEmpty()) {
                DynamicPropertiesCache dynamicPropCache = getCache();
                try {
                    GeneralWFlowDynamicPropertiesHelper generalDynamicHelper = new GeneralWFlowDynamicPropertiesHelper(
                            serverTrimmed, userTrimmed, passwd, dynamicPropCache, workflow);
                    if (generalDynamicHelper.isDynamicPropetiesAvailable()) {
                        msg = "Dynamic properties are required for execution";
                    } else {
                        msg = "Dynamic properties are not required for execution";
                    }
                    return FormValidation.ok(msg);
                } catch (RmWebServiceRuntimeException ex) {
                    String temp = JenkinsValidationUtility.checkCompatibleARA(ex);
                    if (temp != null) {
                        msg = temp;
                    }
                }
            }
            return FormValidation.error(msg);
        }

        /**
         * This method is used to retrieve ARA Entities e.g. workflow.
         */
        private ARAGeneralWorkflowService getRestWebService(String server, String user, Secret pass) {
            String serverTrimmed = server != null ? server.trim() : server;
            String userTrimmed = user != null ? user.trim() : user;
            String passwd = pass == null ? null : Secret.toString(pass);
            String errMsg = JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed);
            if (errMsg == null) {
                return new ARAGeneralWorkflowService(serverTrimmed, userTrimmed, passwd);
            }
            return null;
        }

        @Override
        public boolean isApplicable(Class<? extends AbstractProject> arg0) {
            return false;
        }

        private synchronized DynamicPropertiesCache getCache() {
            return UIUtil.getCache(Stapler.getCurrentRequest().getSession());
        }

    }

    public String getServer() {
        return server;
    }

    public String getUser() {
        return user;
    }

    public Secret getPass() {
        return pass;
    }

    public String getWorkflow() {
        return workflow;
    }

    public String getStartAt() {
        return startAt;
    }

    public String getExecuteAt() {
        return executeAt;
    }

    public String getQueue() {
        return queue;
    }

    public String getManualConfirmation() {
        return manualConfirmation;
    }

    public String getUserGroup() {
        return userGroup;
    }

    public List<GeneralWorkflowDynamicProperty> getDynProps() {
        return dynProps;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Server=").append(server);
        sb.append(", User=").append(user);
        sb.append(", Workflow=").append(workflow);
        if (dynProps != null) {
            sb.append(", Dynamic Properties - ").append(dynProps);
        }
        sb.append(", Start At=").append(startAt);
        sb.append(", Execution Time=").append(executeAt);
        sb.append(", Queue=").append(queue);
        sb.append(", Manual Confirmation=").append(manualConfirmation);
        sb.append(", User/Group=").append(userGroup);
        return sb.toString();
    }

}
