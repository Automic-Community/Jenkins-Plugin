package org.jenkinsci.plugins.ara_general_workflow_execution;

import hudson.EnvVars;
import hudson.Extension;
import hudson.Launcher;
import hudson.model.BuildListener;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.BuildStepMonitor;
import hudson.tasks.Publisher;
import hudson.tasks.Recorder;

import java.io.IOException;
import java.util.List;

import jenkins.model.Jenkins;
import net.sf.json.JSONObject;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.StaplerRequest;

public class AraMultipleGeneralWorkflowExecProp extends Recorder {

    private static final String DISPLAY_NAME = "Execute General Workflow in Automic Release Automation";

    private List<AraGeneralWorkflowExecProp> workflowProp;

    @DataBoundConstructor
    public AraMultipleGeneralWorkflowExecProp(List<AraGeneralWorkflowExecProp> workflowProp) {
        this.workflowProp = workflowProp;
    }

    @Override
    public BuildStepMonitor getRequiredMonitorService() {
        return BuildStepMonitor.NONE;
    }

    @Override
    public WorkflowExecPropDesciptor getDescriptor() {
        return (WorkflowExecPropDesciptor) super.getDescriptor();

    }

    @Override
    public boolean perform(final AbstractBuild<?, ?> build, final Launcher launcher, final BuildListener listener)
            throws IOException, InterruptedException {

        EnvVars envs = build.getEnvironment(listener);

        String jobName = envs.get("JOB_NAME");
        AbstractProject job = Jenkins.getInstance().getItem(jobName, Jenkins.getInstance(), AbstractProject.class);
        // Get Job build status
        if (job == null) {
            listener.getLogger().println("Error : Jenkins Job does not exist!!!");
            return false;
        }

        if (job.getLastBuild().getResult() != hudson.model.Result.SUCCESS) {
            listener.getLogger().println("Error : Last Build is not SUCCESS!!!");
            return false;
        }

        listener.getLogger().println("......Post build step (" + DISPLAY_NAME + ") starts......");
        boolean execution = true;
        for (AraGeneralWorkflowExecProp workflow : getWorkflowProp()) {
            if (!workflow.perform(build, launcher, listener)) {
                listener.getLogger().println(
                        "Error : General workflow execution failed. Skipping execution of general workflows further.");
                execution = false;
                break;
            }
        }
        listener.getLogger().println("......Post build step (" + DISPLAY_NAME + ") ends.......");
        return execution;
    }

    @Extension
    public static final class WorkflowExecPropDesciptor extends BuildStepDescriptor<Publisher> {

        @Override
        public boolean isApplicable(Class<? extends AbstractProject> arg0) {
            return true;
        }

        @Override
        public boolean configure(StaplerRequest req, JSONObject json) throws FormException {
            save();
            return true;
        }

        @Override
        public String getDisplayName() {
            return DISPLAY_NAME;
        }

    }

    public List<AraGeneralWorkflowExecProp> getWorkflowProp() {
        return workflowProp;
    }
}
