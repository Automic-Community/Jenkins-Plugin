package org.jenkinsci.plugins.ara_create_deployment_package;

import hudson.EnvVars;
import hudson.Extension;
import hudson.Launcher;
import hudson.Util;
import hudson.model.BuildListener;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.BuildStepMonitor;
import hudson.tasks.Publisher;
import hudson.tasks.Recorder;
import hudson.util.FormValidation;
import hudson.util.Secret;
import hudson.util.ListBoxModel;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.automic.constants.JenkinsConstants;
import com.automic.util.CommonUtil;
import com.automic.util.JenkinsValidationUtility;
import com.automic.util.WebServiceUtility;

/**
 * Sample {@link Builder}.
 * <p/>
 * <p/>
 * When the user configures the project and enables this builder,
 * {@link org.jenkinsci.plugins.ara_create_deployment_package.PackageComponent.DescriptorImpl#newInstance(StaplerRequest)}
 * is invoked and a new {@link AraCreateDeploymentPackage} is created. The created instance is persisted to the project
 * configuration XML by using XStream, so this allows you to use instance fields (like ) to remember the configuration.
 * <p/>
 * <p/>
 * When a build is performed, the {@link #perform(AbstractBuild, Launcher, BuildListener)} method will be invoked.
 *
 * @author Kohsuke Kawaguchi
 */
public class AraCreateDeploymentPackage extends Recorder {

    private static final Logger LOGGER = LoggerFactory.getLogger(AraCreateDeploymentPackage.class);
    private String server;
    private String user;
    private Secret pass;
    private String pkgName;
    private String pkgType;
    private String appName;
    private String folder;
    private String owner;
    private List<PackageProperty> props;
    private List<PackageDynamicProperty> dynProps;
    private List<PackageComponent> comps;
    private List<String> logs;

    @DataBoundConstructor
    public AraCreateDeploymentPackage(String server, List<PackageComponent> comps,
            List<PackageDynamicProperty> dynProps, List<PackageProperty> props, String owner, String folder,
            String appName, String pkgType, String pkgName, Secret pass, String user) {
        this.server = server;
        this.comps = comps;
        this.dynProps = dynProps;
        this.props = props;
        this.owner = owner;
        this.folder = folder;
        this.appName = appName;
        this.pkgType = pkgType;
        this.pkgName = pkgName;
        this.pass = pass;
        this.user = user;
        this.logs = new ArrayList<String>();
    }

    public BuildStepMonitor getRequiredMonitorService() {
        return BuildStepMonitor.NONE;
    }

    public List<PackageProperty> getProps() {
        return props;
    }

    @Override
    public CreateDeploymentPackageDescriptor getDescriptor() {
        return (CreateDeploymentPackageDescriptor) super.getDescriptor();
    }

    @Override
    public boolean perform(AbstractBuild<?, ?> build, Launcher launcher, BuildListener listener)
            throws InterruptedException, IOException {
        // log ARA entity information
        logs.add(toString());

        // Trim the parameters.
        EnvVars envs = build.getEnvironment(listener);
        String tempServer = getServer() != null ? getServer().trim() : null;
        String tempUser = getUser() != null ? getUser().trim() : null;
        String tempPkgName = getPkgName() != null ? Util.replaceMacro(getPkgName().trim(), envs) : null;
        String tempPkgType = getPkgType() != null ? Util.replaceMacro(getPkgType().trim(), envs) : null;
        String passwd = pass == null ? null : Secret.toString(pass);

        // Validate user input parameters.
        List<String> errors = validate(tempServer, tempUser, tempPkgName, tempPkgType);
        if (errors.size() > 0) {
            logs.add("Error : Invalid input parameters provided. Error details: " + errors);
            return false;
        }

        logs.add("Creating ARA package " + tempPkgName + " of package type " + tempPkgType);
        WebServiceUtility ws = new WebServiceUtility(tempServer, tempUser, passwd);
        try {
            // create package
            if (!ws.createDeploymentPackage(tempPkgName, tempPkgType, getAppName(), getFolder(), getOwner())) {
                logs.add("Error : Create package failed: " + ws.getErrorDetail());
                return false;
            }
            logs.add("Debug : Package is created in ARA");            

            // Assign Component and analyzing log file for Build Output Checks
            if (getComps() != null && !getComps().isEmpty()) {
                Set<String> matchedConditions = evaluateConditions(build, getComps(), envs);
                String packageId = ws.getPackageIdFromPackageName(tempPkgName, tempPkgType);
                List<String> listComp = new ArrayList<String>();
                for (PackageComponent comp : getComps()) {
                    if (CommonUtil.isNotEmpty(comp.getName()) && comp.evaluate(matchedConditions)) {
                        listComp.add(comp.getName());
                    } else {
                        logs.add(String.format("Warn : Component [ %s ] will not be added to package [ %s ]",
                                comp.toString(), tempPkgName));
                    }
                }
                if (!ws.assignPackageComponents(packageId, getAppName(), listComp)) {
                    logs.add("Error : Assign components failed: " + ws.getErrorDetail());
                    return false;
                }
                logs.add("Debug : Components has been assigned to package in ARA.");
            }
            

            // set properties
            List<PackageProperty> props = getProps();
            if (props != null) {
                for (PackageProperty prop : props) {
                    String propName = prop.getName();
                    if (CommonUtil.isNotEmpty(propName)) {
                        String propValue = Util.replaceMacro(prop.getValue(), envs);
                        logs.add("Set Property: Name=" + propName + ", Value=" + propValue);
                        if (!ws.setPackageProperty(tempPkgName, tempPkgType, propName, propValue, getAppName())) {
                            logs.add("Error : Set Property failed: " + ws.getErrorDetail());
                            return false;
                        }
                    } else {
                        logs.add("Skipping Property: Name=" + propName + ", Value=" + prop.getValue());
                    }
                }
            }

            // set dynamic properties
            List<PackageDynamicProperty> dynProps = getDynProps();
            if (dynProps != null) {
                for (PackageDynamicProperty dynProp : dynProps) {
                    String dynPropName = dynProp.getName();
                    if (CommonUtil.isNotEmpty(dynPropName)) {
                        String propValue = Util.replaceMacro(dynProp.getValue(), envs);
                        logs.add("Set DynamicProperty: Name=" + dynPropName + ", Value=" + propValue);
                        if (!ws.setPackageDynamicProperty(tempPkgName, dynPropName, propValue)) {
                            logs.add("Error : Set DynamicProperty failed: " + ws.getErrorDetail());
                            return false;
                        }
                    } else {
                        logs.add("Skipping Property: Name=" + dynPropName + ", Value=" + dynProp.getValue());
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Error in performing build ID:" + build.getId(), e);
            return false;
        }
        logs.add("ARA package " + tempPkgName + " created successfully");
        return true;
    }

    private List<String> validate(String tempServer, String tempUser, String tempPkgName, String tempPkgType) {
        List<String> errors = new ArrayList<String>();

        String errMsg = JenkinsValidationUtility.validateConnectionParameter(tempServer, tempUser);
        if (errMsg != null) {
            errors.add(errMsg);
        }

        errMsg = JenkinsValidationUtility.validatePackageName(tempPkgName);
        if (errMsg != null) {
            errors.add(errMsg);
        }

        if (!CommonUtil.isNotEmpty(tempPkgType)) {
            errors.add("Package Type is mandatory");
        }

        if (!CommonUtil.isNotEmpty(getAppName())) {
            errors.add("Application Name is mandatory");
        }

        if (!CommonUtil.isNotEmpty(getFolder())) {
            errors.add("Package Folder is mandatory");
        }

        if (!CommonUtil.isNotEmpty(getOwner())) {
            errors.add("Package owner is mandatory");
        }

        return errors;
    }

    /**
     * This method evaluates all the user provided conditions and returns the conditions which we found in the build log
     * irrespective of contains/doesn't contain.
     */
    private Set<String> evaluateConditions(AbstractBuild<?, ?> build, List<PackageComponent> comps, EnvVars envs)
            throws IOException {
        Set<String> matchedconditionSet = new HashSet<>();
        Set<String> conditionSet = new HashSet<>();
        Map<String, Pattern> conditionMap = new HashMap<>();
        for (PackageComponent c : comps) {
            for (Condition condition : c.getConditions()) {
                String value = condition.getValue();
                if (CommonUtil.isNotEmpty(value)) {
                    String regex = Util.replaceMacro(value, envs);
                    Pattern pattern;
                    try {
                        pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
                    } catch (Exception e) {
                        pattern = Pattern.compile(Pattern.quote(regex), Pattern.CASE_INSENSITIVE);
                    }
                    value = value.toLowerCase();
                    conditionMap.put(value, pattern);
                    conditionSet.add(value);
                }
            }
        }

        File f = build.getLogFile();
        try (BufferedReader reader = Files.newBufferedReader(f.toPath(), JenkinsConstants.ENCODING)) {
            String line = null;
            while ((line = reader.readLine()) != null) {
                for (Iterator<String> itr = conditionSet.iterator(); itr.hasNext();) {
                    String val = itr.next();
                    if (conditionMap.get(val).matcher(line).find()) {
                        matchedconditionSet.add(val);
                        conditionMap.remove(val);
                        itr.remove();
                    }
                }
                if (conditionSet.isEmpty()) {
                    break;
                }
            }
        }
        return matchedconditionSet;
    }

    /**
     * @return the dynProps
     */
    public List<PackageDynamicProperty> getDynProps() {
        return dynProps;
    }

    /**
     * @return the comps
     */
    public List<PackageComponent> getComps() {
        return comps;
    }

    public String getServer() {
        return server;
    }

    public String getUser() {
        return user;
    }

    public Secret getPass() {
        return pass;
    }

    public String getPkgName() {
        return pkgName;
    }

    public String getPkgType() {
        return pkgType;
    }

    public String getAppName() {
        return appName;
    }

    public String getFolder() {
        return folder;
    }

    public String getOwner() {
        return owner;
    }

    public List<String> readLogs() {
        return logs;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Server=").append(server).append(" User=").append(user);
        sb.append(" Package==").append(pkgName).append(" Package type=").append(pkgType);
        sb.append(" Application=").append(appName).append(" Folder=").append(folder);
        sb.append(" Owner=").append(owner).append(" Components=").append(comps);
        sb.append(" Properties=").append(props).append(" Dynamic Properties=").append(dynProps);
        return sb.toString();
    }

    /**
     * Defines descriptor class for each instance of ARA package.
     */
    @Extension
    public static final class CreateDeploymentPackageDescriptor extends BuildStepDescriptor<Publisher> {

        @Override
        public boolean isApplicable(Class<? extends AbstractProject> type) {
            return false;
        }

        @Override
        public String getDisplayName() {
            return "Create Automic Release Automation Package";
        }

        public FormValidation doCheckServer(@QueryParameter String value) throws IOException {
            String server = value != null ? value.trim() : value;
            String errMsg = JenkinsValidationUtility.validateServerURL(server);
            return errMsg == null ? FormValidation.ok() : FormValidation.error(errMsg);
        }

        public FormValidation doCheckUser(@QueryParameter String value) throws IOException {
            String usrTrimmed = value != null ? value.trim() : value;
            String errMsg = JenkinsValidationUtility.validateUserName(usrTrimmed);
            return errMsg == null ? FormValidation.ok() : FormValidation.error(errMsg);
        }

        public FormValidation doTestConnection(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass)
                throws IOException {

            String serverTrimmed = server != null ? server.trim() : server;
            String userTrimmed = user != null ? user.trim() : user;
            String passwd = pass == null ? null : Secret.toString(pass);
            String errMsg = JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed);
            if (errMsg == null) {
                WebServiceUtility ws = new WebServiceUtility(serverTrimmed, userTrimmed, passwd);
                return ws.testConnection() ? FormValidation.ok("Login successful") : FormValidation
                        .error("Login failed: " + ws.getErrorDetail());
            } else {
                return FormValidation.error("Login failed. Error Message [" + errMsg + "]");
            }
        }

        public FormValidation doCheckPkgName(@QueryParameter String value) throws Exception {
            String packageName = value != null ? value.trim() : value;
            String errMsg = JenkinsValidationUtility.validatePackageName(packageName);
            return errMsg == null ? FormValidation.ok() : FormValidation.error(errMsg);
        }

        public FormValidation doCheckPkgType(@QueryParameter String value,
                @QueryParameter("server") final String server, @QueryParameter("user") final String user,
                @QueryParameter("pass") final Secret pass, @QueryParameter("pkgName") final String pkgName)
                throws Exception {

            String pkgType = value == null ? null : value.trim();
            if (!CommonUtil.isNotEmpty(pkgType)) {
                return FormValidation.error("The Package Type is mandatory");
            }
            String packageName = pkgName != null ? pkgName.trim() : pkgName;
            String serverTrimmed = server != null ? server.trim() : server;
            String userTrimmed = user != null ? user.trim() : user;
            String passwd = pass == null ? null : Secret.toString(pass);
            if (JenkinsValidationUtility.validatePackageName(packageName) == null
                    && JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed) == null) {
                WebServiceUtility ws = new WebServiceUtility(serverTrimmed, userTrimmed, passwd);
                if (ws.checkPackageExist(packageName, pkgType)) {
                    return FormValidation
                            .warning("There is already an existing package for the specified package name and type.");
                } else if (ws.getErrorDetail() != null && pkgType.indexOf("$") == -1) {
                    return FormValidation.error("Invalid package type. " + ws.getErrorDetail());
                }
            }
            return FormValidation.ok();
        }

        public ListBoxModel doFillFolderItems(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass) {
            ListBoxModel items = new ListBoxModel();
            for (String s : getEntities(server, user, pass, "Folder")) {
                items.add(s);
            }
            return items;
        }

        public ListBoxModel doFillOwnerItems(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass) {
            ListBoxModel items = new ListBoxModel();
            items.add(user.trim());
            for (String s : getEntities(server, user, pass, "UserGroup")) {
                items.add(s);
            }
            return items;
        }

        public ListBoxModel doFillAppNameItems(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass) {
            ListBoxModel items = new ListBoxModel();
            for (String s : getEntities(server, user, pass, "Application")) {
                items.add(s);
            }
            return items;
        }

        /**
         * This method is used to retrieve ARA Entities e.g. Owners/applications and folders.
         */
        private List<String> getEntities(String server, String user, Secret pass, String entityType) {
            String serverTrimmed = server != null ? server.trim() : server;
            String userTrimmed = user != null ? user.trim() : user;
            String passwd = pass == null ? null : Secret.toString(pass);
            String errMsg = JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed);
            if (errMsg == null) {
                WebServiceUtility ws = new WebServiceUtility(serverTrimmed, userTrimmed, passwd);
                return ws.getSystemName(entityType, null);
            }
            return Collections.emptyList();
        }
    }
}