package org.jenkinsci.plugins.ara_create_deployment_package;

/**
 * Created with IntelliJ IDEA.
 * User: Administrator
 * Date: 7/18/13
 * Time: 12:05 PM
 * To change this template use File | Settings | File Templates.
 */
import hudson.Extension;
import hudson.model.Describable;
import hudson.model.Descriptor;
import hudson.util.FormValidation;
import jenkins.model.Jenkins;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;

import com.automic.util.CommonUtil;

/**
 *
 * @author Chris Johnson
 */
public class PackageDynamicProperty implements Describable<PackageDynamicProperty> {

    private final String name;
    private final String value;

    @DataBoundConstructor
    public PackageDynamicProperty(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getValue() {
        return value != null ? value.trim() : value;
    }

    public String getName() {
        return name != null ? name.trim() : name;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Name=").append(name).append(" Value=").append(value);        
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    public Descriptor<PackageDynamicProperty> getDescriptor() {
        return Jenkins.getInstance().getDescriptorOrDie(getClass());
    }

    /**
     * Defines descriptor class for each instance of Dynamic property.
     */
    @Extension
    public static class DescriptorImpl extends Descriptor<PackageDynamicProperty> {
        @Override
        public String getDisplayName() {
            return ""; // unused
        }

        public FormValidation doCheckName(@QueryParameter String value) {
            String temp = value != null ? value.trim() : value;
            if (!CommonUtil.isNotEmpty(temp)) {
                return FormValidation.error("The dynamic property name is mandatory");
            }
            return FormValidation.ok();
        }
    }
}
