package org.jenkinsci.plugins.ara_create_deployment_package;

/**
 * Created with IntelliJ IDEA.
 * User: Administrator
 * Date: 7/18/13
 * Time: 12:05 PM
 * To change this template use File | Settings | File Templates.
 */
import hudson.Extension;
import hudson.model.Describable;
import hudson.model.Descriptor;
import hudson.util.FormValidation;
import jenkins.model.Jenkins;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;

import com.automic.util.CommonUtil;

/**
 *
 * @author Chris Johnson
 */
public class PackageProperty implements Describable<PackageProperty> {

    private final String name;
    private final String value;

    @DataBoundConstructor
    public PackageProperty(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getValue() {
        return value != null ? value.trim() : value;
    }

    public String getName() {
        return name != null ? name.trim() : name;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Name=").append(name).append(" Value=").append(value);        
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    public Descriptor<PackageProperty> getDescriptor() {
        return Jenkins.getInstance().getDescriptorOrDie(getClass());
    }

    /**
     * Defines descriptor class for each instance of Package property.
     */
    @Extension
    public static class DescriptorImpl extends Descriptor<PackageProperty> {
        @Override
        public String getDisplayName() {
            return ""; // unused
        }

        public FormValidation doCheckName(@QueryParameter String value) {
            String temp = value != null ? value.trim() : value;
            if (!CommonUtil.isNotEmpty(temp)) {
                return FormValidation.error("The property name is mandatory");
            }
            return FormValidation.ok();
        }
    }
}
