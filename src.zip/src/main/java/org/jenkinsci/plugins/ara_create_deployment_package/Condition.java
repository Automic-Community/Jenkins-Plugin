package org.jenkinsci.plugins.ara_create_deployment_package;

import hudson.Extension;
import hudson.model.Describable;
import hudson.model.Descriptor;
import hudson.util.FormValidation;
import hudson.util.ListBoxModel;

import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import jenkins.model.Jenkins;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;

import com.automic.constants.JenkinsConstants;
import com.automic.util.CommonUtil;

/**
 * @author Anurag
 */
public class Condition implements Describable<Condition> {

    private final String comparator;
    private final String value;

    @DataBoundConstructor
    public Condition(String comparator, String value) {
        this.comparator = comparator;
        this.value = value;
    }

    public String getComparator() {
        return comparator;
    }

    public String getValue() {
        return value != null ? value.trim() : value;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Build Log=").append(comparator).append(" Value=").append(value);
        return sb.toString();
    }

    public boolean evaluate(Set<String> data) {
        String text = getValue();
        if (!CommonUtil.isNotEmpty(text)) {
            return true;
        }

        text = text.toLowerCase();
        boolean match = data.contains(text);
        return JenkinsConstants.COMPARATOR_CONTAIN.equals(getComparator()) ? match : !match;
    }

    @SuppressWarnings("unchecked")
    public Descriptor<Condition> getDescriptor() {
        return Jenkins.getInstance().getDescriptorOrDie(getClass());
    }

    /**
     * Defines descriptor class for condition.
     */
    @Extension
    public static class DescriptorImpl extends Descriptor<Condition> {

        @Override
        public String getDisplayName() {
            return ""; // unused
        }

        public ListBoxModel doFillComparatorItems() {
            ListBoxModel items = new ListBoxModel();
            items.add(JenkinsConstants.COMPARATOR_CONTAIN);
            items.add(JenkinsConstants.COMPARATOR_NOT_CONTAIN);
            return items;
        }

        public FormValidation doCheckValue(@QueryParameter String value) {
            String temp = value != null ? value.trim() : value;
            if (!CommonUtil.isNotEmpty(temp)) {
                return FormValidation.error("The value is mandatory");
            }
            try {
                Pattern.compile(temp, Pattern.CASE_INSENSITIVE);
            } catch (PatternSyntaxException ex) {
                return FormValidation
                        .warning("The value is not valid regular expression, so it will be treated as constant value.");
            }
            return FormValidation.ok();
        }
    }
}
