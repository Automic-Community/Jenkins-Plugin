package org.jenkinsci.plugins.ara_create_deployment_package;

/**
 * Created with IntelliJ IDEA.
 * User: Administrator
 * Date: 7/18/13
 * Time: 12:05 PM
 * To change this template use File | Settings | File Templates.
 */

import hudson.Extension;
import hudson.RelativePath;
import hudson.model.Describable;
import hudson.model.Descriptor;
import hudson.util.Secret;
import hudson.util.ListBoxModel;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import jenkins.model.Jenkins;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;

import com.automic.util.CommonUtil;
import com.automic.util.JenkinsValidationUtility;
import com.automic.util.WebServiceUtility;

/**
 * @author Chris Johnson
 */
public class PackageComponent implements Describable<PackageComponent> {

    private final String name;
    private List<Condition> conditions;

    @DataBoundConstructor
    public PackageComponent(String name, List<Condition> conditions) {
        this.name = name;
        this.conditions = conditions;
    }

    public String getName() {
        return name;
    }

    public List<Condition> getConditions() {
        return conditions == null ? Collections.<Condition>emptyList() : conditions;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Comp Name=").append(name).append(" Conditions=").append(conditions);        
        return sb.toString();
    }


    public boolean evaluate(Set<String> data) {
        List<Condition> conds = getConditions();
        boolean match = true;
        for (Condition cond : conds) {
            match = cond.evaluate(data);
            if (!match) {
                break;
            }
        }
        return match;
    }

    @SuppressWarnings("unchecked")
    public Descriptor<PackageComponent> getDescriptor() {
        return Jenkins.getInstance().getDescriptorOrDie(getClass());
    }

    /**
     * Defines descriptor class for each package component.
     */
    @Extension
    public static class DescriptorImpl extends Descriptor<PackageComponent> {

        @Override
        public String getDisplayName() {
            return ""; // unused
        }

        /*
         * public FormValidation doCheckName(@QueryParameter String value) { if (value.length() == 0) { return
         * FormValidation.error("The component name is mandatory"); }
         * 
         * return FormValidation.ok();, }
         */

        public ListBoxModel doFillNameItems(@QueryParameter(value = "server") @RelativePath("..") final String server,
                @QueryParameter(value = "user") @RelativePath("..") final String user,
                @QueryParameter(value = "pass") @RelativePath("..") final Secret pass,
                @QueryParameter(value = "appName") @RelativePath("..") String application) {
            ListBoxModel items = new ListBoxModel();
            
            String serverTrimmed = server != null ? server.trim() : server;
            String userTrimmed = user != null ? user.trim() : user;
            String passwd = pass == null ? null : Secret.toString(pass);
            String errMsg = JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed);
            if (errMsg == null && CommonUtil.isNotEmpty(application) ) {
                String[] condition = { "system_application.system_name eq '" + application + "'" };
                WebServiceUtility ws = new WebServiceUtility(server, user, passwd);
                for (String s : ws.getSystemName("Component", condition)) {
                    items.add(s);
                }
            }            
            return items;
        }
    }
}
