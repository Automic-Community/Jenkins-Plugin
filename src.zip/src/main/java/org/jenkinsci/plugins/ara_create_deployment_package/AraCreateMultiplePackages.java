/**
 * 
 */
package org.jenkinsci.plugins.ara_create_deployment_package;

import hudson.EnvVars;
import hudson.Extension;
import hudson.Launcher;
import hudson.model.BuildListener;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.BuildStepMonitor;
import hudson.tasks.Publisher;
import hudson.tasks.Recorder;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import jenkins.model.Jenkins;
import net.sf.json.JSONObject;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.StaplerRequest;

/**
 * This describable lets user Create multiple {@link AraCreateDeploymentPackage} within itself.
 *
 */
public class AraCreateMultiplePackages extends Recorder {

    private static final String DISPLAY_NAME = "Create Automic Release Automation Package";
    private List<AraCreateDeploymentPackage> packagebuilders;

    @DataBoundConstructor
    public AraCreateMultiplePackages(List<AraCreateDeploymentPackage> packagebuilders) {
        this.packagebuilders = packagebuilders;
    }

    public List<AraCreateDeploymentPackage> getPackagebuilders() {
        if (packagebuilders == null) {
            packagebuilders = Collections.<AraCreateDeploymentPackage> emptyList();
        }
        return packagebuilders;
    }

    @Override
    public boolean perform(final AbstractBuild<?, ?> build, final Launcher launcher, final BuildListener listener)
            throws InterruptedException, IOException {
        EnvVars envs = build.getEnvironment(listener);

        String jobName = envs.get("JOB_NAME");
        AbstractProject job = Jenkins.getInstance().getItem(jobName, Jenkins.getInstance(), AbstractProject.class);
        // Get Job build status
        if (job == null) {
            listener.getLogger().println("Error : Jenkins Job does not exist!!!");
            return false;
        }

        if (job.getLastBuild().getResult() != hudson.model.Result.SUCCESS) {
            listener.getLogger().println("Error : Last Build is not SUCCESS!!!");
            return false;
        }

        boolean buildSuccess = true;
        for (AraCreateDeploymentPackage buildStep : packagebuilders) {
            if (!buildStep.perform(build, launcher, listener)) {
                buildSuccess = false;
                break;
            }
        }

        // We should not do in line logging as it may interfere the condition evaluation.
        listener.getLogger().println("......Post build step (" + DISPLAY_NAME + ") starts......");
        for (AraCreateDeploymentPackage buildStep : packagebuilders) {
            for (String log : buildStep.readLogs()) {
                listener.getLogger().println(log);
            }
        }
        if (!buildSuccess) {
            listener.getLogger().println("Error : Package creation failed. Will not create any package further.");
        }
        listener.getLogger().println("......Post build step (" + DISPLAY_NAME + ") ends.......");
        return buildSuccess;
    }

    @Override
    public CreateMultiplePackageDescriptor getDescriptor() {
        return (CreateMultiplePackageDescriptor) super.getDescriptor();
    }

    /*
     * (non-Javadoc)
     * 
     * @see hudson.tasks.BuildStep#getRequiredMonitorService()
     */
    @Override
    public BuildStepMonitor getRequiredMonitorService() {
        //
        return BuildStepMonitor.NONE;
    }

    /**
     * Defines descriptor class for post build step ARA Create package.
     */
    @Extension
    public static class CreateMultiplePackageDescriptor extends BuildStepDescriptor<Publisher> {

        @Override
        public boolean configure(StaplerRequest req, JSONObject json) throws FormException {
            save();
            return true;
        }

        @Override
        public boolean isApplicable(Class<? extends AbstractProject> jobType) {
            //
            return true;
        }

        @Override
        public String getDisplayName() {
            return DISPLAY_NAME;
        }

    }

}
