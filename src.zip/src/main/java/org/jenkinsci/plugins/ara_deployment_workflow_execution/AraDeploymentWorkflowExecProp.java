package org.jenkinsci.plugins.ara_deployment_workflow_execution;

import hudson.EnvVars;
import hudson.Extension;
import hudson.Launcher;
import hudson.Util;
import hudson.model.BuildListener;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.BuildStepMonitor;
import hudson.tasks.Publisher;
import hudson.tasks.Recorder;
import hudson.util.ComboBoxModel;
import hudson.util.FormValidation;
import hudson.util.Secret;
import hudson.util.ListBoxModel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.QueryParameter;
import org.kohsuke.stapler.Stapler;

import com.automic.helper.dynproperty.AppWfDynamicPropertiesHelper;
import com.automic.helper.dynproperty.DynamicPropertiesCache;
import com.automic.jenkinsui.util.UIUtil;
import com.automic.util.CommonUtil;
import com.automic.util.JenkinsValidationUtility;
import com.automic.ws.rest.ARADeploymentWorkflowService;
import com.automic.ws.rest.model.ExecutionResponse;
import com.automic.ws.rest.model.dynamicprop.DynamicProperties;
import com.automic.ws.rest.model.workflow.DeploymentWorkflowProperties;
import com.automic.ws.rest.model.workflow.WorkflowProperties;

public class AraDeploymentWorkflowExecProp extends Recorder {

    private String server;
    private String user;
    private Secret pass;
    private String appName;
    private String workflow;
    private String pkgName;
    private String profile;
    private String startAt;
    private String executeAt;
    private String queue;
    private String manualConfirmation;
    private String userGroup;
    private String installationMode;
    private List<DeploymentWorkflowDynamicProperty> dynProps;

    @DataBoundConstructor
    public AraDeploymentWorkflowExecProp(String server, String user, Secret pass, String appName, String workflow,
            String pkgName, String profile, String startAt, String executeAt, String queue, String manualConfirmation,
            String userGroup, String installationMode, List<DeploymentWorkflowDynamicProperty> dynProps) {
        this.server = server;
        this.user = user;
        this.pass = pass;
        this.appName = appName;
        this.workflow = workflow;
        this.pkgName = pkgName;
        this.profile = profile;
        this.startAt = startAt;
        this.executeAt = executeAt;
        this.queue = queue;
        this.manualConfirmation = manualConfirmation;
        this.userGroup = userGroup;
        this.installationMode = installationMode;
        this.dynProps = dynProps;
    }

    @Override
    public BuildStepMonitor getRequiredMonitorService() {
        return BuildStepMonitor.NONE;
    }

    @Override
    public DeploymentWorkflowDescriptor getDescriptor() {
        return (DeploymentWorkflowDescriptor) super.getDescriptor();
    }

    @Override
    public boolean perform(AbstractBuild<?, ?> build, Launcher launcher, BuildListener listener)
            throws InterruptedException, IOException {

        // log ARA entity information
        listener.getLogger().println(toString());

        EnvVars envs = build.getEnvironment(listener);
        String tempServer = getServer() != null ? getServer().trim() : null;
        String tempUser = getUser() != null ? getUser().trim() : null;
        String passwd = getPass() == null ? null : Secret.toString(getPass());
        String tempExecTime = getExecuteAt() != null ? Util.replaceMacro(getExecuteAt().trim(), envs) : null;
        String tempPackage = getPkgName() != null ? Util.replaceMacro(getPkgName().trim(), envs) : null;
        listener.getLogger().println("Info : Package Name " + tempPackage);

        List<String> errors = validate(tempServer, tempUser, tempExecTime, tempPackage);
        if (errors.size() > 0) {
            listener.getLogger().println("Error : Invalid input parameters provided. Error details: " + errors);
            return false;
        }

        try (ARADeploymentWorkflowService ws = new ARADeploymentWorkflowService(tempServer, tempUser, passwd)) {
            DynamicProperties araDynamicProperties = null;
            if (dynProps != null && dynProps.size() > 0) {
                Map<String, String> uiDynamicPropMap = new HashMap<>();
                for (DeploymentWorkflowDynamicProperty prop : dynProps) {
                    String propValue = prop.getPropValue() != null ? Util
                            .replaceMacro(prop.getPropValue().trim(), envs) : null;
                    listener.getLogger().println("Dynamic Property " + prop.getPropName() + ":=" + propValue);
                    String temp = uiDynamicPropMap.put(prop.getPropName(), propValue);
                    if (temp != null) {
                        listener.getLogger().println(
                                "Warning : Duplicate Prompt property [" + prop.getPropName()
                                        + "] has been specified. Will override the value [" + propValue + "]");
                    }
                }
                DynamicProperties uiDynamicProperties = AppWfDynamicPropertiesHelper
                        .getDynamicProperty(uiDynamicPropMap);
                araDynamicProperties = ws
                        .getApplicationDynamicProperties(getAppName(), getWorkflow(), tempPackage, getProfile());
                araDynamicProperties = araDynamicProperties.merge(uiDynamicProperties);
            }

            String wfName = getWorkflow();
            DeploymentWorkflowProperties workflowExecProperties = new DeploymentWorkflowProperties(wfName,
                    getStartAt(), getManualConfirmation(), araDynamicProperties);

            if (WorkflowProperties.STATAT_EXECAT.equals(getStartAt())) {
                workflowExecProperties.setExecuteAt(CommonUtil.convertToARADateFormat(tempExecTime));
            } else if (WorkflowProperties.STARTAT_QUEUE.equals(getStartAt())) {
                workflowExecProperties.setQueue(getQueue());
            }

            if (!WorkflowProperties.CONFIRM_NO.equals(getManualConfirmation())) {
                workflowExecProperties.setUserGroup(getUserGroup());
            }

            workflowExecProperties.setAppWfProperties(getAppName(), tempPackage, getProfile(), getInstallationMode());

            listener.getLogger().println("Executing ARA Application Workflow : " + getWorkflow());
            listener.getLogger().println("Info : JSON Request :");
            String json = workflowExecProperties.prepareRequestJson();
            listener.getLogger().println(json);
            ExecutionResponse exeResponse = ws.executeWorkflow(json);

            listener.getLogger().println(
                    "Info : ARA Application Workflow " + getWorkflow() + " executed successfully, " + exeResponse);

        } catch (Exception e) {
            String errMsg = JenkinsValidationUtility.checkCompatibleARA(e);
            if (errMsg != null) {
                listener.getLogger().println("Error: " + errMsg);
            }
            listener.getLogger().println(
                    "Error : Execution of application workflow[" + getWorkflow() + "] failed. Reason- "
                            + e.getMessage());
            listener.getLogger().println("Error in performing build ID:" + build.getId());
            return false;
        }
        return true;
    }

    private List<String> validate(String tempServer, String tempUser, String executionTime, String tempPackage) {
        List<String> errors = new ArrayList<String>();

        String errMsg = JenkinsValidationUtility.validateConnectionParameter(tempServer, tempUser);
        if (errMsg != null) {
            errors.add(errMsg);
        }

        if (!CommonUtil.isNotEmpty(getAppName()) || CommonUtil.isNotEmpty(getAppName())
                && UIUtil.OPTION_PLEASE_SELECT.equals(getAppName())) {
            errors.add("Application name is not provided");
        }

        String workflowName = getWorkflow();
        if (!CommonUtil.isNotEmpty(workflowName) || CommonUtil.isNotEmpty(workflowName)
                && UIUtil.OPTION_PLEASE_SELECT.equals(workflowName)) {
            errors.add("Workflow name is not provided");
        }

        if (workflowName.endsWith("(*)") && CommonUtil.isNotEmpty(getProfile())) {
            errors.add("Profile should not be provided");
        }

        if (!CommonUtil.isNotEmpty(tempPackage)) {
            errors.add("Package name is not provided");
        }

        if (getDynProps() != null) {
            for (DeploymentWorkflowDynamicProperty prop : getDynProps()) {
                String error = prop.validate();
                if (error != null) {
                    errors.add(error);
                    break;
                }
            }
        }

        if (WorkflowProperties.STARTAT_QUEUE.equals(getStartAt()) && !CommonUtil.isNotEmpty(getQueue())) {
            errors.add("Queue is not provided");
        }

        if (WorkflowProperties.STATAT_EXECAT.equals(getStartAt())) {
            errMsg = JenkinsValidationUtility.validateExecutionTime(executionTime);
            if (errMsg != null) {
                errors.add(errMsg);
            }
        }

        if (!WorkflowProperties.CONFIRM_NO.equals(getManualConfirmation()) && !CommonUtil.isNotEmpty(getUserGroup())) {
            errors.add("User/User Group is not provided");
        }

        return errors;
    }

    @Extension
    public static class DeploymentWorkflowDescriptor extends BuildStepDescriptor<Publisher> {

        public FormValidation doCheckServer(@QueryParameter String value) throws IOException {
            String server = value != null ? value.trim() : value;
            String errMsg = JenkinsValidationUtility.validateServerURL(server);
            return errMsg == null ? FormValidation.ok() : FormValidation.error(errMsg);
        }

        public FormValidation doCheckUser(@QueryParameter String value) throws IOException {
            String usrTrimmed = value != null ? value.trim() : value;
            String errMsg = JenkinsValidationUtility.validateUserName(usrTrimmed);
            return errMsg == null ? FormValidation.ok() : FormValidation.error(errMsg);
        }

        public FormValidation doTestConnection(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass)
                throws IOException {
            return UIUtil.testConnection(server, user, pass);
        }

        public ListBoxModel doFillAppNameItems(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass) {
            ListBoxModel items = null;
            try (ARADeploymentWorkflowService ws = getRestWebService(server, user, pass)) {
                if (ws != null) {
                    List<String> appList = ws.getApplicationList();
                    items = UIUtil.sortedListModel(appList, true);
                }
            }
            return items == null ? new ListBoxModel() : items;
        }

        public ListBoxModel doFillWorkflowItems(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass,
                @QueryParameter("appName") final String appName) {
            ListBoxModel items = null;
            if (CommonUtil.isNotEmpty(appName) && !UIUtil.OPTION_PLEASE_SELECT.equals(appName)) {
                try (ARADeploymentWorkflowService ws = getRestWebService(server, user, pass)) {
                    if (ws != null) {
                        List<String> wfList = ws.getApplicationWorkflowList(appName);
                        items = UIUtil.sortedListModel(wfList, true);
                    }
                }
            }
            return items == null ? new ListBoxModel() : items;
        }

        public ComboBoxModel doFillPkgNameItems(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass,
                @QueryParameter("appName") final String appName) {
            ComboBoxModel items = new ComboBoxModel();
            if (CommonUtil.isNotEmpty(appName) && !UIUtil.OPTION_PLEASE_SELECT.equals(appName)) {
                try (ARADeploymentWorkflowService ws = getRestWebService(server, user, pass)) {
                    if (ws != null) {
                        List<String> pkgList = ws.getPackageList(appName);
                        Collections.sort(pkgList);
                        items.addAll(pkgList);
                    }
                }
            }
            return items;
        }

        public ListBoxModel doFillProfileItems(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass,
                @QueryParameter("appName") final String appName, @QueryParameter("workflow") final String workflow) {
            ListBoxModel items = null;
            if (CommonUtil.isNotEmpty(appName) && !UIUtil.OPTION_PLEASE_SELECT.equals(appName)
                    && CommonUtil.isNotEmpty(workflow) && !workflow.endsWith("(*)")
                    && !UIUtil.OPTION_PLEASE_SELECT.equals(workflow)) {
                try (ARADeploymentWorkflowService ws = getRestWebService(server, user, pass)) {
                    if (ws != null) {
                        List<String> pflList = ws.getProfileList(appName);
                        /*
                         * Collections.sort(pflList); int c = 0; for (String s : pflList) { items.add(new
                         * ListBoxModel.Option(s, s, ((c == 0) ? true : false))); c = 1; }
                         */
                        items = UIUtil.sortedListModel(pflList, false);
                    }
                }
            }
            return items == null ? new ListBoxModel() : items;
        }

        public ListBoxModel doFillStartAtItems() {
            return UIUtil.getStartAtItems();
        }

        public ListBoxModel doFillQueueItems(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass,
                @QueryParameter("profile") final String profile, @QueryParameter("appName") final String appName,
                @QueryParameter("workflow") final String workflow, @QueryParameter("startAt") final String startAt) {
            ListBoxModel items = null;
            if (WorkflowProperties.STARTAT_QUEUE.equals(startAt)) {
                try (ARADeploymentWorkflowService ws = getRestWebService(server, user, pass)) {
                    if (ws != null) {
                        List<String> lst = null;
                        if (CommonUtil.isNotEmpty(workflow) && workflow.endsWith("(*)")) {
                            lst = ws.getActiveQueues();
                            items = UIUtil.sortedListModel(lst, false);
                        } else if (CommonUtil.isNotEmpty(appName) && !UIUtil.OPTION_PLEASE_SELECT.equals(appName)) {
                            lst = ws.getProfileQueues(profile, appName);
                            items = UIUtil.sortedListModel(lst, false);
                        }
                    }
                }
            }
            return items == null ? new ListBoxModel() : items;
        }

        public FormValidation doCheckExecuteAt(@QueryParameter String value,
                @QueryParameter("startAt") final String startAt) throws IOException {
            return UIUtil.validateStartAt(startAt, value);
        }

        public ListBoxModel doFillManualConfirmationItems() {
            return UIUtil.getManualConfirmationItems();
        }

        public ListBoxModel doFillUserGroupItems(@QueryParameter("server") String server,
                @QueryParameter("user") String user, @QueryParameter("pass") Secret pass,
                @QueryParameter("manualConfirmation") String manualConfirmation) {
            ListBoxModel items = null;
            if ((manualConfirmation != null) && (!WorkflowProperties.CONFIRM_NO.equals(manualConfirmation))) {
                try (ARADeploymentWorkflowService ws = getRestWebService(server, user, pass)) {
                    if (ws != null) {
                        List<String> list = ws.getUsersOrUserGroups(manualConfirmation);
                        items = UIUtil.sortedListModel(list, false);
                    }
                } catch (Exception ex) {
                    items = new ListBoxModel();
                    items.add(user);
                }
            }
            return items == null ? new ListBoxModel() : items;
        }

        public FormValidation doCheckDynamicProperties(@QueryParameter("server") final String server,
                @QueryParameter("user") final String user, @QueryParameter("pass") final Secret pass,
                @QueryParameter("appName") final String appName, @QueryParameter("workflow") final String workflow,
                @QueryParameter("pkgName") final String pkgName, @QueryParameter("profile") final String profile)
                throws IOException {

            String msg = "Necessary Parameters are not provided.";
            String serverTrimmed = server != null ? server.trim() : server;
            String userTrimmed = user != null ? user.trim() : user;
            String passwd = pass == null ? null : Secret.toString(pass);
            String errMsg = JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed);
            if (errMsg == null && CommonUtil.isNotEmpty(appName)) {
                DynamicPropertiesCache dynamicPropCache = getCache();
                try {
                    AppWfDynamicPropertiesHelper appDynamicHelper = new AppWfDynamicPropertiesHelper(serverTrimmed,
                            userTrimmed, passwd, dynamicPropCache, appName, workflow, pkgName, profile);
                    if (appDynamicHelper.isDynamicPropetiesAvailable()) {
                        msg = "Dynamic properties are required for execution";
                    } else {
                        msg = "Dynamic properties are not required for execution";
                    }
                    return FormValidation.ok(msg);
                } catch (Exception ex) {
                    String temp = JenkinsValidationUtility.checkCompatibleARA(ex);
                    if (temp != null) {
                        msg = temp;
                    }
                }
            }
            return FormValidation.error(msg);
        }

        /**
         * This method is used to retrieve ARA Entities e.g. workflow.
         */
        private ARADeploymentWorkflowService getRestWebService(String server, String user, Secret pass) {
            String serverTrimmed = server != null ? server.trim() : server;
            String userTrimmed = user != null ? user.trim() : user;
            String passwd = pass == null ? null : Secret.toString(pass);
            String errMsg = JenkinsValidationUtility.validateConnectionParameter(serverTrimmed, userTrimmed);
            if (errMsg == null) {
                return new ARADeploymentWorkflowService(serverTrimmed, userTrimmed, passwd);
            }
            return null;
        }

        @Override
        public boolean isApplicable(Class<? extends AbstractProject> paramClass) {
            return false;
        }

        private synchronized DynamicPropertiesCache getCache() {            
            return UIUtil.getCache(Stapler.getCurrentRequest().getSession());
        }
    }

    public String getServer() {
        return server;
    }

    public String getUser() {
        return user;
    }

    public Secret getPass() {
        return pass;
    }

    public String getWorkflow() {
        return workflow;
    }

    public String getStartAt() {
        return startAt;
    }

    public String getExecuteAt() {
        return executeAt;
    }

    public String getQueue() {
        return queue;
    }

    public String getManualConfirmation() {
        return manualConfirmation;
    }

    public String getUserGroup() {
        return userGroup;
    }

    public String getInstallationMode() {
        return installationMode;
    }

    public List<DeploymentWorkflowDynamicProperty> getDynProps() {
        return dynProps;
    }

    public String getAppName() {
        return appName;
    }

    public String getPkgName() {
        return pkgName;
    }

    public String getProfile() {
        return profile;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        sb.append("Server=").append(server);
        sb.append(", User=").append(user);
        sb.append(", Application=").append(appName);
        sb.append(", Workflow=").append(workflow);
        sb.append(", Package=").append(pkgName);
        sb.append(", Profile=").append(profile);
        if (dynProps != null) {
            sb.append(", Dynamic Properties - ").append(dynProps);
        }
        sb.append(", Start At=").append(startAt);
        sb.append(", Execution Time=").append(executeAt);
        sb.append(", Queue=").append(queue);
        sb.append(", Manual Confirmation=").append(manualConfirmation);
        sb.append(", User/Group=").append(userGroup);
        sb.append(", Installation Mode=").append(installationMode);
        return sb.toString();
    }
}
